import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, real, boolean, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// User types
export const UserRole = {
  STUDENT: "student",
  INSTRUCTOR: "instructor",
  ADMIN: "admin",
} as const;

export type UserRoleType = typeof UserRole[keyof typeof UserRole];

// Team roles for students
export const TeamRole = {
  STRATEGIC_SOURCING_MANAGER: "strategic_sourcing_manager",
  SUPPLIER_EVALUATION_ANALYST: "supplier_evaluation_analyst",
  CONTRACT_RISK_MANAGER: "contract_risk_manager",
  ESG_SUSTAINABILITY_OFFICER: "esg_sustainability_officer",
  REPORTING_ANALYST: "reporting_analyst",
} as const;

export type TeamRoleType = typeof TeamRole[keyof typeof TeamRole];

// Round status
export const RoundStatus = {
  NOT_STARTED: "not_started",
  IN_PROGRESS: "in_progress",
  COMPLETED: "completed",
} as const;

export type RoundStatusType = typeof RoundStatus[keyof typeof RoundStatus];

// Users table
export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  name: text("name").notNull(),
  role: text("role").notNull().default("student"),
  email: text("email"),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  name: true,
  role: true,
  email: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

// Scenarios table
export const scenarios = pgTable("scenarios", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  description: text("description"),
  instructorId: varchar("instructor_id").notNull(),
  productCategory: text("product_category").notNull(),
  demandPattern: text("demand_pattern").notNull(), // stable, fluctuating
  targetReliability: real("target_reliability"),
  targetMaxCost: real("target_max_cost"),
  targetMinEsg: real("target_min_esg"),
  isTemplate: boolean("is_template").default(false),
});

export const insertScenarioSchema = createInsertSchema(scenarios).omit({ id: true });
export type InsertScenario = z.infer<typeof insertScenarioSchema>;
export type Scenario = typeof scenarios.$inferSelect;

// Suppliers table
export const suppliers = pgTable("suppliers", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  scenarioId: varchar("scenario_id").notNull(),
  name: text("name").notNull(),
  country: text("country").notNull(),
  isLocal: boolean("is_local").default(true),
  unitPrice: real("unit_price").notNull(),
  volumeDiscount: real("volume_discount").default(0),
  leadTime: integer("lead_time").notNull(), // days
  leadTimeVariability: real("lead_time_variability").default(0),
  onTimeDeliveryRate: real("on_time_delivery_rate").notNull(),
  defectRate: real("defect_rate").default(0),
  esgEnvironmental: real("esg_environmental").notNull(),
  esgSocial: real("esg_social").notNull(),
  esgGovernance: real("esg_governance").notNull(),
  riskLevel: text("risk_level").notNull(), // low, medium, high
  capacity: integer("capacity").notNull(),
});

export const insertSupplierSchema = createInsertSchema(suppliers).omit({ id: true });
export type InsertSupplier = z.infer<typeof insertSupplierSchema>;
export type Supplier = typeof suppliers.$inferSelect;

// Classes/Sessions table
export const sessions = pgTable("sessions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  instructorId: varchar("instructor_id").notNull(),
  scenarioId: varchar("scenario_id").notNull(),
  isActive: boolean("is_active").default(true),
  currentRound: integer("current_round").default(0),
  maxRounds: integer("max_rounds").default(4),
});

export const insertSessionSchema = createInsertSchema(sessions).omit({ id: true });
export type InsertSession = z.infer<typeof insertSessionSchema>;
export type Session = typeof sessions.$inferSelect;

// Teams table
export const teams = pgTable("teams", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  sessionId: varchar("session_id").notNull(),
  name: text("name").notNull(),
  currentRound: integer("current_round").default(0),
});

export const insertTeamSchema = createInsertSchema(teams).omit({ id: true });
export type InsertTeam = z.infer<typeof insertTeamSchema>;
export type Team = typeof teams.$inferSelect;

// Team Members table
export const teamMembers = pgTable("team_members", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  teamId: varchar("team_id").notNull(),
  userId: varchar("user_id").notNull(),
  teamRole: text("team_role").notNull(),
});

export const insertTeamMemberSchema = createInsertSchema(teamMembers).omit({ id: true });
export type InsertTeamMember = z.infer<typeof insertTeamMemberSchema>;
export type TeamMember = typeof teamMembers.$inferSelect;

// Decisions table
export const decisions = pgTable("decisions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  teamId: varchar("team_id").notNull(),
  roundNumber: integer("round_number").notNull(),
  supplierId: varchar("supplier_id").notNull(),
  volumeAllocation: real("volume_allocation").notNull(), // percentage
  contractDuration: integer("contract_duration"), // months
  contractType: text("contract_type"), // short_term, long_term, spot
  esgInitiatives: jsonb("esg_initiatives"),
  isLocked: boolean("is_locked").default(false),
});

export const insertDecisionSchema = createInsertSchema(decisions).omit({ id: true });
export type InsertDecision = z.infer<typeof insertDecisionSchema>;
export type Decision = typeof decisions.$inferSelect;

// KPI Results table
export const kpiResults = pgTable("kpi_results", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  teamId: varchar("team_id").notNull(),
  roundNumber: integer("round_number").notNull(),
  reliabilityScore: real("reliability_score").notNull(),
  totalCost: real("total_cost").notNull(),
  esgScore: real("esg_score").notNull(),
  riskIndex: real("risk_index").notNull(),
  agilityScore: real("agility_score"),
  onTimeDelivery: real("on_time_delivery"),
  qualityScore: real("quality_score"),
});

export const insertKpiResultSchema = createInsertSchema(kpiResults).omit({ id: true });
export type InsertKpiResult = z.infer<typeof insertKpiResultSchema>;
export type KpiResult = typeof kpiResults.$inferSelect;

// Activity Logs for learning analytics
export const activityLogs = pgTable("activity_logs", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull(),
  teamId: varchar("team_id"),
  action: text("action").notNull(),
  details: jsonb("details"),
  timestamp: text("timestamp").notNull(),
});

export const insertActivityLogSchema = createInsertSchema(activityLogs).omit({ id: true });
export type InsertActivityLog = z.infer<typeof insertActivityLogSchema>;
export type ActivityLog = typeof activityLogs.$inferSelect;

// KPI Weights for scoring
export interface KpiWeights {
  reliability: number;
  cost: number;
  esg: number;
  risk: number;
}

// Supplier with calculated scores
export interface SupplierWithScore extends Supplier {
  compositeScore: number;
  reliabilityScore: number;
  costScore: number;
  esgScore: number;
}

// Round information
export interface RoundInfo {
  number: number;
  name: string;
  description: string;
  duration: string;
  features: string[];
  status: RoundStatusType;
}

// Team with members
export interface TeamWithMembers extends Team {
  members: (TeamMember & { user: User })[];
  kpiResults?: KpiResult[];
}

// Session with details
export interface SessionWithDetails extends Session {
  scenario: Scenario;
  teams: TeamWithMembers[];
  instructor: User;
}
