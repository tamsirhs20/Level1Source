import { Switch, Route, Redirect } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { ThemeProvider } from "@/lib/theme-provider";
import { AuthProvider, useAuth } from "@/lib/auth-context";
import { SidebarProvider, SidebarTrigger } from "@/components/ui/sidebar";
import { AppSidebar } from "@/components/app-sidebar";
import { ThemeToggle } from "@/components/theme-toggle";
import NotFound from "@/pages/not-found";
import LoginPage from "@/pages/login";
import StudentDashboard from "@/pages/student/dashboard";
import SuppliersPage from "@/pages/student/suppliers";
import SimulationPage from "@/pages/student/simulation";
import TeamPage from "@/pages/student/team";
import InstructorDashboard from "@/pages/instructor/dashboard";
import ScenariosPage from "@/pages/instructor/scenarios";
import SessionsPage from "@/pages/instructor/sessions";
import TeamsPage from "@/pages/instructor/teams";
import AnalyticsPage from "@/pages/instructor/analytics";
import AdminDashboard from "@/pages/admin/dashboard";
import UsersPage from "@/pages/admin/users";
import { UserRole } from "@shared/schema";

function ProtectedRoute({
  component: Component,
  allowedRoles,
}: {
  component: React.ComponentType;
  allowedRoles?: string[];
}) {
  const { user, isLoading } = useAuth();

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-screen">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary" />
      </div>
    );
  }

  if (!user) {
    return <Redirect to="/login" />;
  }

  if (allowedRoles && !allowedRoles.includes(user.role)) {
    return <Redirect to="/" />;
  }

  return <Component />;
}

function AppLayout({ children }: { children: React.ReactNode }) {
  const sidebarStyle = {
    "--sidebar-width": "16rem",
    "--sidebar-width-icon": "3rem",
  };

  return (
    <SidebarProvider style={sidebarStyle as React.CSSProperties}>
      <div className="flex h-screen w-full">
        <AppSidebar />
        <div className="flex flex-col flex-1 overflow-hidden">
          <header className="flex items-center justify-between gap-4 p-3 border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
            <SidebarTrigger data-testid="button-sidebar-toggle" />
            <ThemeToggle />
          </header>
          <main className="flex-1 overflow-auto">{children}</main>
        </div>
      </div>
    </SidebarProvider>
  );
}

function HomeRedirect() {
  const { user } = useAuth();

  if (!user) {
    return <Redirect to="/login" />;
  }

  switch (user.role) {
    case UserRole.INSTRUCTOR:
      return <Redirect to="/instructor" />;
    case UserRole.ADMIN:
      return <Redirect to="/admin" />;
    default:
      return <Redirect to="/student" />;
  }
}

function Router() {
  const { user } = useAuth();

  return (
    <Switch>
      <Route path="/login" component={LoginPage} />

      <Route path="/">
        <HomeRedirect />
      </Route>

      {/* Student Routes */}
      <Route path="/student">
        <AppLayout>
          <ProtectedRoute
            component={StudentDashboard}
            allowedRoles={[UserRole.STUDENT]}
          />
        </AppLayout>
      </Route>
      <Route path="/student/suppliers">
        <AppLayout>
          <ProtectedRoute
            component={SuppliersPage}
            allowedRoles={[UserRole.STUDENT]}
          />
        </AppLayout>
      </Route>
      <Route path="/student/simulation">
        <AppLayout>
          <ProtectedRoute
            component={SimulationPage}
            allowedRoles={[UserRole.STUDENT]}
          />
        </AppLayout>
      </Route>
      <Route path="/student/team">
        <AppLayout>
          <ProtectedRoute
            component={TeamPage}
            allowedRoles={[UserRole.STUDENT]}
          />
        </AppLayout>
      </Route>

      {/* Instructor Routes */}
      <Route path="/instructor">
        <AppLayout>
          <ProtectedRoute
            component={InstructorDashboard}
            allowedRoles={[UserRole.INSTRUCTOR]}
          />
        </AppLayout>
      </Route>
      <Route path="/instructor/scenarios">
        <AppLayout>
          <ProtectedRoute
            component={ScenariosPage}
            allowedRoles={[UserRole.INSTRUCTOR]}
          />
        </AppLayout>
      </Route>
      <Route path="/instructor/sessions">
        <AppLayout>
          <ProtectedRoute
            component={SessionsPage}
            allowedRoles={[UserRole.INSTRUCTOR]}
          />
        </AppLayout>
      </Route>
      <Route path="/instructor/teams">
        <AppLayout>
          <ProtectedRoute
            component={TeamsPage}
            allowedRoles={[UserRole.INSTRUCTOR]}
          />
        </AppLayout>
      </Route>
      <Route path="/instructor/analytics">
        <AppLayout>
          <ProtectedRoute
            component={AnalyticsPage}
            allowedRoles={[UserRole.INSTRUCTOR]}
          />
        </AppLayout>
      </Route>

      {/* Admin Routes */}
      <Route path="/admin">
        <AppLayout>
          <ProtectedRoute
            component={AdminDashboard}
            allowedRoles={[UserRole.ADMIN]}
          />
        </AppLayout>
      </Route>
      <Route path="/admin/users">
        <AppLayout>
          <ProtectedRoute
            component={UsersPage}
            allowedRoles={[UserRole.ADMIN]}
          />
        </AppLayout>
      </Route>
      <Route path="/admin/settings">
        <AppLayout>
          <ProtectedRoute
            component={AdminDashboard}
            allowedRoles={[UserRole.ADMIN]}
          />
        </AppLayout>
      </Route>

      {/* Fallback to 404 */}
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <ThemeProvider defaultTheme="light" storageKey="scor-ui-theme">
        <AuthProvider>
          <TooltipProvider>
            <Toaster />
            <Router />
          </TooltipProvider>
        </AuthProvider>
      </ThemeProvider>
    </QueryClientProvider>
  );
}

export default App;
