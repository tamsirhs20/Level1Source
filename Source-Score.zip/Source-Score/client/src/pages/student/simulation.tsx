import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Slider } from "@/components/ui/slider";
import { Skeleton } from "@/components/ui/skeleton";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { RoundTimeline, defaultRounds } from "@/components/round-timeline";
import { SupplierCard } from "@/components/supplier-card";
import { ScoringPanel } from "@/components/scoring-panel";
import { KpiCard } from "@/components/kpi-card";
import { useToast } from "@/hooks/use-toast";
import { queryClient, apiRequest } from "@/lib/queryClient";
import {
  Play,
  Lock,
  CheckCircle,
  AlertTriangle,
  TrendingUp,
  DollarSign,
  Leaf,
  Clock,
  Package,
  FileText,
  Lightbulb,
} from "lucide-react";
import type { Supplier, Team, KpiWeights, Decision, KpiResult } from "@shared/schema";

interface SupplierAllocation {
  supplierId: string;
  allocation: number;
  contractType: string;
  contractDuration: number;
}

export default function SimulationPage() {
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState("strategy");
  const [allocations, setAllocations] = useState<SupplierAllocation[]>([]);
  const [weights, setWeights] = useState<KpiWeights>({
    reliability: 25,
    cost: 25,
    esg: 25,
    risk: 25,
  });
  const [showConfirmDialog, setShowConfirmDialog] = useState(false);

  const { data: myTeam, isLoading: teamLoading } = useQuery<Team>({
    queryKey: ["/api/student/my-team"],
  });

  const { data: suppliers, isLoading: suppliersLoading } = useQuery<Supplier[]>({
    queryKey: ["/api/suppliers"],
  });

  const { data: kpiHistory } = useQuery<KpiResult[]>({
    queryKey: ["/api/student/kpi-history"],
    enabled: !!myTeam,
  });

  const lockDecisionMutation = useMutation({
    mutationFn: async (decisions: SupplierAllocation[]) => {
      return apiRequest("POST", "/api/decisions/lock", { decisions });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/student/my-team"] });
      queryClient.invalidateQueries({ queryKey: ["/api/student/kpi-history"] });
      toast({
        title: "Decisions Locked",
        description: "Your sourcing decisions have been submitted for this round.",
      });
      setShowConfirmDialog(false);
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to submit decisions. Please try again.",
        variant: "destructive",
      });
    },
  });

  const currentRound = myTeam?.currentRound || 0;
  const rounds = defaultRounds.map((round, index) => ({
    ...round,
    status:
      index < currentRound
        ? "completed"
        : index === currentRound
        ? "current"
        : "locked",
  })) as typeof defaultRounds;

  const currentRoundInfo = rounds[currentRound] || rounds[0];

  const handleAllocationChange = (supplierId: string, value: number[]) => {
    setAllocations((prev) => {
      const existing = prev.find((a) => a.supplierId === supplierId);
      if (existing) {
        return prev.map((a) =>
          a.supplierId === supplierId ? { ...a, allocation: value[0] } : a
        );
      }
      return [...prev, { supplierId, allocation: value[0], contractType: "spot", contractDuration: 1 }];
    });
  };

  const handleContractChange = (supplierId: string, field: "contractType" | "contractDuration", value: string | number) => {
    setAllocations((prev) => {
      const existing = prev.find((a) => a.supplierId === supplierId);
      if (existing) {
        return prev.map((a) =>
          a.supplierId === supplierId ? { ...a, [field]: value } : a
        );
      }
      return [...prev, { supplierId, allocation: 0, contractType: field === "contractType" ? value as string : "spot", contractDuration: field === "contractDuration" ? value as number : 1 }];
    });
  };

  const totalAllocation = allocations.reduce((sum, a) => sum + a.allocation, 0);
  const isValidAllocation = totalAllocation === 100;

  const handleLockDecisions = () => {
    if (isValidAllocation) {
      lockDecisionMutation.mutate(allocations);
    }
  };

  if (teamLoading || suppliersLoading) {
    return (
      <div className="p-6 space-y-6">
        <Skeleton className="h-10 w-48" />
        <Skeleton className="h-16" />
        <div className="grid gap-4 md:grid-cols-2">
          <Skeleton className="h-96" />
          <Skeleton className="h-96" />
        </div>
      </div>
    );
  }

  if (!myTeam) {
    return (
      <div className="p-6">
        <Card className="py-12 text-center">
          <CardContent>
            <AlertTriangle className="w-12 h-12 mx-auto text-muted-foreground mb-4" />
            <h3 className="font-semibold text-lg">No Active Session</h3>
            <p className="text-muted-foreground mt-2">
              You need to be assigned to a team to access the simulation.
            </p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold">Sourcing Simulation</h1>
          <p className="text-muted-foreground">{myTeam.name}</p>
        </div>
        <div className="flex items-center gap-4">
          <RoundTimeline rounds={rounds} currentRound={currentRound} />
        </div>
      </div>

      <Card className="bg-muted/30">
        <CardContent className="p-4">
          <div className="flex items-start gap-4">
            <div className="flex items-center justify-center w-12 h-12 rounded-lg bg-primary/10">
              <Play className="w-6 h-6 text-primary" />
            </div>
            <div className="flex-1">
              <h3 className="font-semibold">{currentRoundInfo.name}</h3>
              <p className="text-sm text-muted-foreground mt-1">
                {currentRoundInfo.description}
              </p>
            </div>
            <Badge variant="outline">
              <Clock className="w-3 h-3 mr-1" />
              25 min remaining
            </Badge>
          </div>
        </CardContent>
      </Card>

      <div className="grid gap-4 md:grid-cols-4">
        <KpiCard
          title="Reliability"
          value={kpiHistory?.[0]?.reliabilityScore?.toFixed(0) || "--"}
          unit="%"
          icon={<TrendingUp className="w-5 h-5 text-blue-500" />}
          testId="sim-kpi-reliability"
        />
        <KpiCard
          title="Total Cost"
          value={kpiHistory?.[0]?.totalCost ? `$${kpiHistory[0].totalCost.toLocaleString()}` : "--"}
          icon={<DollarSign className="w-5 h-5 text-green-500" />}
          testId="sim-kpi-cost"
        />
        <KpiCard
          title="ESG Score"
          value={kpiHistory?.[0]?.esgScore?.toFixed(0) || "--"}
          unit="/100"
          icon={<Leaf className="w-5 h-5 text-emerald-500" />}
          testId="sim-kpi-esg"
        />
        <KpiCard
          title="Risk Index"
          value={kpiHistory?.[0]?.riskIndex?.toFixed(1) || "--"}
          icon={<AlertTriangle className="w-5 h-5 text-orange-500" />}
          testId="sim-kpi-risk"
        />
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
        <TabsList>
          <TabsTrigger value="strategy" data-testid="tab-strategy">
            <Package className="w-4 h-4 mr-2" />
            Strategy & Allocation
          </TabsTrigger>
          <TabsTrigger value="contracts" data-testid="tab-contracts">
            <FileText className="w-4 h-4 mr-2" />
            Contracts
          </TabsTrigger>
          <TabsTrigger value="esg" data-testid="tab-esg">
            <Leaf className="w-4 h-4 mr-2" />
            ESG Initiatives
          </TabsTrigger>
        </TabsList>

        <TabsContent value="strategy" className="space-y-4">
          <div className="grid gap-6 lg:grid-cols-[1fr,320px]">
            <div className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Volume Allocation</CardTitle>
                  <CardDescription>
                    Allocate procurement volume across suppliers (must total 100%)
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="flex items-center justify-between p-3 rounded-md bg-muted/50">
                    <span className="font-medium">Total Allocation</span>
                    <Badge variant={isValidAllocation ? "default" : "destructive"}>
                      {totalAllocation}%
                    </Badge>
                  </div>

                  {suppliers?.map((supplier) => {
                    const allocation = allocations.find((a) => a.supplierId === supplier.id);
                    return (
                      <div key={supplier.id} className="space-y-3 p-4 rounded-lg border">
                        <div className="flex items-center justify-between">
                          <div>
                            <p className="font-medium">{supplier.name}</p>
                            <p className="text-sm text-muted-foreground">
                              ${supplier.unitPrice}/unit | {supplier.country}
                            </p>
                          </div>
                          <span className="text-xl font-bold font-mono text-primary">
                            {allocation?.allocation || 0}%
                          </span>
                        </div>
                        <Slider
                          value={[allocation?.allocation || 0]}
                          onValueChange={(v) => handleAllocationChange(supplier.id, v)}
                          max={100}
                          step={5}
                          data-testid={`slider-allocation-${supplier.id}`}
                        />
                        <div className="flex gap-2 text-xs">
                          <Badge variant="outline">
                            Reliability: {(supplier.onTimeDeliveryRate * 100).toFixed(0)}%
                          </Badge>
                          <Badge variant="outline">
                            Risk: {supplier.riskLevel}
                          </Badge>
                        </div>
                      </div>
                    );
                  })}

                  {!isValidAllocation && (
                    <div className="flex items-center gap-2 p-3 rounded-md bg-destructive/10 text-destructive">
                      <AlertTriangle className="w-4 h-4" />
                      <span className="text-sm">
                        Allocation must total exactly 100% (currently {totalAllocation}%)
                      </span>
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>

            <div className="space-y-4">
              <ScoringPanel
                weights={weights}
                suppliers={suppliers || []}
                onWeightsChange={setWeights}
              />

              <Card className="bg-amber-500/10 border-amber-500/20">
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm flex items-center gap-2">
                    <Lightbulb className="w-4 h-4 text-amber-500" />
                    Hint
                  </CardTitle>
                </CardHeader>
                <CardContent className="text-sm">
                  Consider diversifying across multiple suppliers to reduce risk.
                  Balance cost savings with reliability for stable supply.
                </CardContent>
              </Card>
            </div>
          </div>
        </TabsContent>

        <TabsContent value="contracts" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Contract Configuration</CardTitle>
              <CardDescription>
                Define contract terms for each selected supplier
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {allocations
                .filter((a) => a.allocation > 0)
                .map((allocation) => {
                  const supplier = suppliers?.find((s) => s.id === allocation.supplierId);
                  if (!supplier) return null;
                  return (
                    <div key={allocation.supplierId} className="p-4 rounded-lg border space-y-4">
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="font-medium">{supplier.name}</p>
                          <p className="text-sm text-muted-foreground">
                            {allocation.allocation}% volume allocation
                          </p>
                        </div>
                      </div>
                      <div className="grid gap-4 sm:grid-cols-2">
                        <div className="space-y-2">
                          <label className="text-sm font-medium">Contract Type</label>
                          <Select
                            value={allocation.contractType}
                            onValueChange={(v) => handleContractChange(supplier.id, "contractType", v)}
                          >
                            <SelectTrigger data-testid={`select-contract-type-${supplier.id}`}>
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="spot">Spot Purchase</SelectItem>
                              <SelectItem value="short_term">Short-Term (3-6 months)</SelectItem>
                              <SelectItem value="long_term">Long-Term (12+ months)</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                        <div className="space-y-2">
                          <label className="text-sm font-medium">Duration (months)</label>
                          <Select
                            value={String(allocation.contractDuration)}
                            onValueChange={(v) => handleContractChange(supplier.id, "contractDuration", parseInt(v))}
                          >
                            <SelectTrigger data-testid={`select-duration-${supplier.id}`}>
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="1">1 month</SelectItem>
                              <SelectItem value="3">3 months</SelectItem>
                              <SelectItem value="6">6 months</SelectItem>
                              <SelectItem value="12">12 months</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                      </div>
                    </div>
                  );
                })}

              {allocations.filter((a) => a.allocation > 0).length === 0 && (
                <p className="text-center text-muted-foreground py-8">
                  Allocate volume to suppliers first to configure contracts.
                </p>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="esg" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">ESG Initiatives</CardTitle>
              <CardDescription>
                Select sustainability initiatives to implement
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {[
                { id: "audit", name: "Supplier ESG Audit Program", cost: 5000, impact: "+5 ESG Score" },
                { id: "certification", name: "Sustainability Certification Support", cost: 8000, impact: "+8 ESG Score" },
                { id: "carbon", name: "Carbon Footprint Reduction Initiative", cost: 12000, impact: "+12 ESG Score" },
                { id: "community", name: "Community Development Partnership", cost: 6000, impact: "+6 ESG Score" },
              ].map((initiative) => (
                <div
                  key={initiative.id}
                  className="flex items-center justify-between p-4 rounded-lg border hover-elevate cursor-pointer"
                >
                  <div className="flex items-center gap-3">
                    <div className="flex items-center justify-center w-10 h-10 rounded-md bg-emerald-500/10">
                      <Leaf className="w-5 h-5 text-emerald-500" />
                    </div>
                    <div>
                      <p className="font-medium">{initiative.name}</p>
                      <p className="text-sm text-muted-foreground">
                        Cost: ${initiative.cost.toLocaleString()}
                      </p>
                    </div>
                  </div>
                  <Badge variant="secondary">{initiative.impact}</Badge>
                </div>
              ))}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      <div className="flex justify-end gap-3">
        <Button variant="outline" data-testid="button-save-draft">
          Save Draft
        </Button>
        <Button
          onClick={() => setShowConfirmDialog(true)}
          disabled={!isValidAllocation}
          data-testid="button-lock-decisions"
        >
          <Lock className="w-4 h-4 mr-2" />
          Lock Decisions
        </Button>
      </div>

      <Dialog open={showConfirmDialog} onOpenChange={setShowConfirmDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Confirm Your Decisions</DialogTitle>
            <DialogDescription>
              Once locked, your decisions cannot be changed for this round.
              Make sure you've reviewed your strategy carefully.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-3 py-4">
            <h4 className="font-medium">Summary:</h4>
            {allocations
              .filter((a) => a.allocation > 0)
              .map((allocation) => {
                const supplier = suppliers?.find((s) => s.id === allocation.supplierId);
                return (
                  <div key={allocation.supplierId} className="flex justify-between p-2 rounded bg-muted">
                    <span>{supplier?.name}</span>
                    <span className="font-mono font-medium">{allocation.allocation}%</span>
                  </div>
                );
              })}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowConfirmDialog(false)}>
              Cancel
            </Button>
            <Button
              onClick={handleLockDecisions}
              disabled={lockDecisionMutation.isPending}
              data-testid="button-confirm-lock"
            >
              {lockDecisionMutation.isPending ? "Submitting..." : "Confirm & Lock"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
