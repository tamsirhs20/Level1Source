import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { SupplierCard } from "@/components/supplier-card";
import { ScoringPanel } from "@/components/scoring-panel";
import { Search, Filter, ArrowUpDown, Grid3X3, List } from "lucide-react";
import type { Supplier, KpiWeights } from "@shared/schema";

export default function SuppliersPage() {
  const [searchQuery, setSearchQuery] = useState("");
  const [riskFilter, setRiskFilter] = useState<string>("all");
  const [sortBy, setSortBy] = useState<string>("name");
  const [viewMode, setViewMode] = useState<"grid" | "list">("grid");
  const [selectedSupplier, setSelectedSupplier] = useState<Supplier | null>(null);
  const [weights, setWeights] = useState<KpiWeights>({
    reliability: 25,
    cost: 25,
    esg: 25,
    risk: 25,
  });

  const { data: suppliers, isLoading } = useQuery<Supplier[]>({
    queryKey: ["/api/suppliers"],
  });

  const calculateScore = (supplier: Supplier): number => {
    const reliabilityScore = supplier.onTimeDeliveryRate * 100 * (weights.reliability / 100);
    const costScore = (100 - (supplier.unitPrice / 200) * 100) * (weights.cost / 100);
    const esgScore =
      ((supplier.esgEnvironmental + supplier.esgSocial + supplier.esgGovernance) / 3) *
      (weights.esg / 100);
    const riskScore =
      (supplier.riskLevel === "low" ? 100 : supplier.riskLevel === "medium" ? 50 : 20) *
      (weights.risk / 100);
    return reliabilityScore + costScore + esgScore + riskScore;
  };

  const filteredSuppliers = (suppliers || [])
    .filter((s) => {
      if (searchQuery && !s.name.toLowerCase().includes(searchQuery.toLowerCase())) {
        return false;
      }
      if (riskFilter !== "all" && s.riskLevel !== riskFilter) {
        return false;
      }
      return true;
    })
    .sort((a, b) => {
      switch (sortBy) {
        case "score":
          return calculateScore(b) - calculateScore(a);
        case "price":
          return a.unitPrice - b.unitPrice;
        case "reliability":
          return b.onTimeDeliveryRate - a.onTimeDeliveryRate;
        case "esg":
          const esgA = (a.esgEnvironmental + a.esgSocial + a.esgGovernance) / 3;
          const esgB = (b.esgEnvironmental + b.esgSocial + b.esgGovernance) / 3;
          return esgB - esgA;
        default:
          return a.name.localeCompare(b.name);
      }
    });

  if (isLoading) {
    return (
      <div className="p-6 space-y-6">
        <Skeleton className="h-10 w-48" />
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {[1, 2, 3, 4, 5, 6].map((i) => (
            <Skeleton key={i} className="h-64" />
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Supplier Profiles</h1>
        <p className="text-muted-foreground">
          Evaluate and compare suppliers based on KPIs
        </p>
      </div>

      <div className="grid gap-6 lg:grid-cols-[1fr,320px]">
        <div className="space-y-4">
          <div className="flex flex-col sm:flex-row gap-3">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input
                placeholder="Search suppliers..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-9"
                data-testid="input-search-suppliers"
              />
            </div>
            <div className="flex gap-2">
              <Select value={riskFilter} onValueChange={setRiskFilter}>
                <SelectTrigger className="w-[130px]" data-testid="select-risk-filter">
                  <Filter className="w-4 h-4 mr-2" />
                  <SelectValue placeholder="Risk" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Risks</SelectItem>
                  <SelectItem value="low">Low Risk</SelectItem>
                  <SelectItem value="medium">Medium Risk</SelectItem>
                  <SelectItem value="high">High Risk</SelectItem>
                </SelectContent>
              </Select>
              <Select value={sortBy} onValueChange={setSortBy}>
                <SelectTrigger className="w-[140px]" data-testid="select-sort">
                  <ArrowUpDown className="w-4 h-4 mr-2" />
                  <SelectValue placeholder="Sort" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="name">Name</SelectItem>
                  <SelectItem value="score">Score</SelectItem>
                  <SelectItem value="price">Price</SelectItem>
                  <SelectItem value="reliability">Reliability</SelectItem>
                  <SelectItem value="esg">ESG Score</SelectItem>
                </SelectContent>
              </Select>
              <div className="flex border rounded-md">
                <Button
                  variant={viewMode === "grid" ? "secondary" : "ghost"}
                  size="icon"
                  onClick={() => setViewMode("grid")}
                  data-testid="button-view-grid"
                >
                  <Grid3X3 className="w-4 h-4" />
                </Button>
                <Button
                  variant={viewMode === "list" ? "secondary" : "ghost"}
                  size="icon"
                  onClick={() => setViewMode("list")}
                  data-testid="button-view-list"
                >
                  <List className="w-4 h-4" />
                </Button>
              </div>
            </div>
          </div>

          <div className="flex items-center justify-between">
            <p className="text-sm text-muted-foreground">
              Showing {filteredSuppliers.length} suppliers
            </p>
            <div className="flex gap-1">
              <Badge variant="secondary">Low: {filteredSuppliers.filter(s => s.riskLevel === "low").length}</Badge>
              <Badge variant="outline">Medium: {filteredSuppliers.filter(s => s.riskLevel === "medium").length}</Badge>
              <Badge variant="destructive">High: {filteredSuppliers.filter(s => s.riskLevel === "high").length}</Badge>
            </div>
          </div>

          <div
            className={
              viewMode === "grid"
                ? "grid gap-4 sm:grid-cols-2"
                : "space-y-3"
            }
          >
            {filteredSuppliers.map((supplier) => (
              <SupplierCard
                key={supplier.id}
                supplier={supplier}
                compositeScore={calculateScore(supplier)}
                onViewDetails={() => setSelectedSupplier(supplier)}
                showActions={true}
              />
            ))}
          </div>

          {filteredSuppliers.length === 0 && (
            <Card className="py-12 text-center">
              <CardContent>
                <p className="text-muted-foreground">
                  No suppliers found matching your criteria.
                </p>
              </CardContent>
            </Card>
          )}
        </div>

        <div className="space-y-4">
          <ScoringPanel
            weights={weights}
            suppliers={suppliers || []}
            onWeightsChange={setWeights}
          />

          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm">SCOR Source Context</CardTitle>
            </CardHeader>
            <CardContent className="text-sm text-muted-foreground space-y-2">
              <p>
                <strong>S1:</strong> Source Stocked Product - Regular, forecast-based procurement
              </p>
              <p>
                <strong>S2:</strong> Source Make-to-Order - Order-triggered sourcing
              </p>
              <p>
                <strong>S3:</strong> Source Engineer-to-Order - Custom specifications
              </p>
            </CardContent>
          </Card>
        </div>
      </div>

      <Dialog open={!!selectedSupplier} onOpenChange={() => setSelectedSupplier(null)}>
        <DialogContent className="max-w-2xl">
          {selectedSupplier && (
            <>
              <DialogHeader>
                <DialogTitle>{selectedSupplier.name}</DialogTitle>
                <DialogDescription>
                  Detailed supplier profile and performance metrics
                </DialogDescription>
              </DialogHeader>
              <div className="space-y-4 py-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-1">
                    <p className="text-sm text-muted-foreground">Country</p>
                    <p className="font-medium">{selectedSupplier.country}</p>
                  </div>
                  <div className="space-y-1">
                    <p className="text-sm text-muted-foreground">Type</p>
                    <p className="font-medium">{selectedSupplier.isLocal ? "Local" : "Global"}</p>
                  </div>
                  <div className="space-y-1">
                    <p className="text-sm text-muted-foreground">Unit Price</p>
                    <p className="font-medium font-mono">${selectedSupplier.unitPrice}</p>
                  </div>
                  <div className="space-y-1">
                    <p className="text-sm text-muted-foreground">Volume Discount</p>
                    <p className="font-medium font-mono">{selectedSupplier.volumeDiscount}%</p>
                  </div>
                  <div className="space-y-1">
                    <p className="text-sm text-muted-foreground">Lead Time</p>
                    <p className="font-medium font-mono">{selectedSupplier.leadTime} days</p>
                  </div>
                  <div className="space-y-1">
                    <p className="text-sm text-muted-foreground">Lead Time Variability</p>
                    <p className="font-medium font-mono">
                      {(selectedSupplier.leadTimeVariability * 100).toFixed(0)}%
                    </p>
                  </div>
                  <div className="space-y-1">
                    <p className="text-sm text-muted-foreground">On-Time Delivery</p>
                    <p className="font-medium font-mono">
                      {(selectedSupplier.onTimeDeliveryRate * 100).toFixed(0)}%
                    </p>
                  </div>
                  <div className="space-y-1">
                    <p className="text-sm text-muted-foreground">Defect Rate</p>
                    <p className="font-medium font-mono">
                      {(selectedSupplier.defectRate * 100).toFixed(1)}%
                    </p>
                  </div>
                </div>

                <div className="pt-4 border-t">
                  <h4 className="font-medium mb-3">ESG Scores</h4>
                  <div className="grid grid-cols-3 gap-4">
                    <div className="p-3 rounded-md bg-green-500/10 text-center">
                      <p className="text-sm text-muted-foreground">Environmental</p>
                      <p className="text-2xl font-bold font-mono text-green-600 dark:text-green-400">
                        {selectedSupplier.esgEnvironmental}
                      </p>
                    </div>
                    <div className="p-3 rounded-md bg-blue-500/10 text-center">
                      <p className="text-sm text-muted-foreground">Social</p>
                      <p className="text-2xl font-bold font-mono text-blue-600 dark:text-blue-400">
                        {selectedSupplier.esgSocial}
                      </p>
                    </div>
                    <div className="p-3 rounded-md bg-purple-500/10 text-center">
                      <p className="text-sm text-muted-foreground">Governance</p>
                      <p className="text-2xl font-bold font-mono text-purple-600 dark:text-purple-400">
                        {selectedSupplier.esgGovernance}
                      </p>
                    </div>
                  </div>
                </div>

                <div className="pt-4 border-t">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-muted-foreground">Production Capacity</p>
                      <p className="font-medium font-mono">
                        {selectedSupplier.capacity.toLocaleString()} units/month
                      </p>
                    </div>
                    <Badge
                      variant={
                        selectedSupplier.riskLevel === "low"
                          ? "secondary"
                          : selectedSupplier.riskLevel === "medium"
                          ? "outline"
                          : "destructive"
                      }
                    >
                      {selectedSupplier.riskLevel.toUpperCase()} RISK
                    </Badge>
                  </div>
                </div>
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
