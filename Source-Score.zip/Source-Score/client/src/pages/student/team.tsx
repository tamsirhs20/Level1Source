import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { useAuth } from "@/lib/auth-context";
import { TeamRole } from "@shared/schema";
import {
  Users,
  Building2,
  BarChart3,
  FileText,
  Leaf,
  ClipboardList,
  Crown,
} from "lucide-react";
import type { TeamWithMembers } from "@shared/schema";

const roleDetails: Record<string, { label: string; icon: React.ElementType; description: string; color: string }> = {
  [TeamRole.STRATEGIC_SOURCING_MANAGER]: {
    label: "Strategic Sourcing Manager",
    icon: Building2,
    description: "Configure sourcing strategy: local/global, single/multiple sourcing, contract horizon",
    color: "text-blue-500 bg-blue-500/10",
  },
  [TeamRole.SUPPLIER_EVALUATION_ANALYST]: {
    label: "Supplier Evaluation Analyst",
    icon: BarChart3,
    description: "Score and rank suppliers using KPIs: reliability, cost, ESG, quality",
    color: "text-green-500 bg-green-500/10",
  },
  [TeamRole.CONTRACT_RISK_MANAGER]: {
    label: "Contract & Risk Manager",
    icon: FileText,
    description: "Design contracts with duration, volume, flexibility, and manage supply risks",
    color: "text-orange-500 bg-orange-500/10",
  },
  [TeamRole.ESG_SUSTAINABILITY_OFFICER]: {
    label: "ESG & Sustainability Officer",
    icon: Leaf,
    description: "Evaluate ESG scores and implement sustainable sourcing initiatives",
    color: "text-emerald-500 bg-emerald-500/10",
  },
  [TeamRole.REPORTING_ANALYST]: {
    label: "Reporting & Learning Analyst",
    icon: ClipboardList,
    description: "Compile recommendations and justify final sourcing strategy",
    color: "text-purple-500 bg-purple-500/10",
  },
};

export default function TeamPage() {
  const { user } = useAuth();

  const { data: team, isLoading } = useQuery<TeamWithMembers>({
    queryKey: ["/api/student/my-team-details"],
  });

  const getInitials = (name: string) => {
    return name
      .split(" ")
      .map((n) => n[0])
      .join("")
      .toUpperCase()
      .slice(0, 2);
  };

  if (isLoading) {
    return (
      <div className="p-6 space-y-6">
        <Skeleton className="h-10 w-48" />
        <div className="grid gap-4 md:grid-cols-2">
          {[1, 2, 3, 4].map((i) => (
            <Skeleton key={i} className="h-40" />
          ))}
        </div>
      </div>
    );
  }

  if (!team) {
    return (
      <div className="p-6">
        <Card className="py-12 text-center">
          <CardContent>
            <Users className="w-12 h-12 mx-auto text-muted-foreground mb-4" />
            <h3 className="font-semibold text-lg">Not Assigned to a Team</h3>
            <p className="text-muted-foreground mt-2">
              Please wait for your instructor to assign you to a team.
            </p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      <div>
        <h1 className="text-2xl font-bold">{team.name}</h1>
        <p className="text-muted-foreground">
          Your team for the SCOR Source simulation
        </p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-lg flex items-center gap-2">
            <Users className="w-5 h-5" />
            Team Members ({team.members.length})
          </CardTitle>
          <CardDescription>
            Each team member has a specific role in the sourcing process
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 md:grid-cols-2">
            {team.members.map((member) => {
              const roleInfo = roleDetails[member.teamRole];
              const isCurrentUser = member.userId === user?.id;
              const IconComponent = roleInfo?.icon || Users;

              return (
                <Card
                  key={member.id}
                  className={isCurrentUser ? "ring-2 ring-primary" : ""}
                >
                  <CardContent className="p-4">
                    <div className="flex items-start gap-4">
                      <Avatar className="w-12 h-12">
                        <AvatarFallback className={roleInfo?.color || "bg-muted"}>
                          {getInitials(member.user.name)}
                        </AvatarFallback>
                      </Avatar>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 flex-wrap">
                          <p className="font-semibold truncate">{member.user.name}</p>
                          {isCurrentUser && (
                            <Badge variant="secondary" className="text-xs">
                              <Crown className="w-3 h-3 mr-1" />
                              You
                            </Badge>
                          )}
                        </div>
                        <div className="flex items-center gap-2 mt-1">
                          <IconComponent className={`w-4 h-4 ${roleInfo?.color.split(" ")[0]}`} />
                          <span className="text-sm font-medium">
                            {roleInfo?.label || member.teamRole}
                          </span>
                        </div>
                        <p className="text-xs text-muted-foreground mt-2">
                          {roleInfo?.description}
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Role Responsibilities</CardTitle>
          <CardDescription>
            Understanding each role's contribution to the sourcing strategy
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {Object.entries(roleDetails).map(([key, info]) => {
              const IconComponent = info.icon;
              const isFilled = team.members.some((m) => m.teamRole === key);
              return (
                <div
                  key={key}
                  className="flex items-start gap-4 p-4 rounded-lg border"
                >
                  <div className={`flex items-center justify-center w-10 h-10 rounded-md ${info.color}`}>
                    <IconComponent className="w-5 h-5" />
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <p className="font-medium">{info.label}</p>
                      <Badge variant={isFilled ? "default" : "outline"}>
                        {isFilled ? "Assigned" : "Vacant"}
                      </Badge>
                    </div>
                    <p className="text-sm text-muted-foreground mt-1">
                      {info.description}
                    </p>
                  </div>
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
