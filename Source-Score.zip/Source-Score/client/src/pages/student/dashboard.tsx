import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { KpiCard } from "@/components/kpi-card";
import { RoundTimeline, defaultRounds } from "@/components/round-timeline";
import { useAuth } from "@/lib/auth-context";
import { Link } from "wouter";
import {
  TrendingUp,
  DollarSign,
  Leaf,
  AlertTriangle,
  Play,
  Users,
  BookOpen,
  Clock,
} from "lucide-react";
import type { Session, Team, KpiResult } from "@shared/schema";

export default function StudentDashboard() {
  const { user } = useAuth();

  const { data: myTeam, isLoading: teamLoading } = useQuery<Team>({
    queryKey: ["/api/student/my-team"],
  });

  const { data: activeSession, isLoading: sessionLoading } = useQuery<Session>({
    queryKey: ["/api/student/active-session"],
  });

  const { data: latestKpi } = useQuery<KpiResult>({
    queryKey: ["/api/student/latest-kpi"],
    enabled: !!myTeam,
  });

  const rounds = defaultRounds.map((round, index) => ({
    ...round,
    status:
      myTeam && myTeam.currentRound !== undefined
        ? index < myTeam.currentRound
          ? "completed"
          : index === myTeam.currentRound
          ? "current"
          : "locked"
        : round.status,
  })) as typeof defaultRounds;

  if (teamLoading || sessionLoading) {
    return (
      <div className="p-6 space-y-6">
        <Skeleton className="h-10 w-48" />
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          {[1, 2, 3, 4].map((i) => (
            <Skeleton key={i} className="h-32" />
          ))}
        </div>
        <Skeleton className="h-64" />
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold" data-testid="text-welcome">
            Welcome, {user?.name}
          </h1>
          <p className="text-muted-foreground">
            Your strategic sourcing simulation dashboard
          </p>
        </div>
        {activeSession && (
          <Link href="/student/simulation">
            <Button size="lg" data-testid="button-start-simulation">
              <Play className="w-4 h-4 mr-2" />
              Continue Simulation
            </Button>
          </Link>
        )}
      </div>

      {myTeam ? (
        <>
          <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4 p-4 rounded-lg bg-muted/50">
            <div className="flex items-center gap-3">
              <div className="flex items-center justify-center w-12 h-12 rounded-lg bg-primary/10">
                <Users className="w-6 h-6 text-primary" />
              </div>
              <div>
                <p className="font-semibold">{myTeam.name}</p>
                <p className="text-sm text-muted-foreground">Your Team</p>
              </div>
            </div>
            <div className="sm:ml-auto flex items-center gap-2">
              <Badge variant="outline" className="text-sm">
                <Clock className="w-3 h-3 mr-1" />
                Round {myTeam.currentRound || 0}
              </Badge>
            </div>
          </div>

          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Round Progress</CardTitle>
              <CardDescription>
                Complete each round to advance your sourcing strategy
              </CardDescription>
            </CardHeader>
            <CardContent>
              <RoundTimeline
                rounds={rounds}
                currentRound={myTeam.currentRound || 0}
                className="justify-center"
              />
            </CardContent>
          </Card>

          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
            <KpiCard
              title="Reliability Score"
              value={latestKpi?.reliabilityScore?.toFixed(0) || "--"}
              unit="%"
              change={latestKpi ? 5 : undefined}
              changeLabel="vs last round"
              icon={<TrendingUp className="w-5 h-5 text-blue-500" />}
              variant="default"
              testId="kpi-reliability"
            />
            <KpiCard
              title="Total Cost"
              value={latestKpi?.totalCost ? `$${latestKpi.totalCost.toLocaleString()}` : "--"}
              change={latestKpi ? -3 : undefined}
              changeLabel="vs last round"
              icon={<DollarSign className="w-5 h-5 text-green-500" />}
              variant="default"
              testId="kpi-cost"
            />
            <KpiCard
              title="ESG Score"
              value={latestKpi?.esgScore?.toFixed(0) || "--"}
              unit="/100"
              change={latestKpi ? 8 : undefined}
              changeLabel="vs last round"
              icon={<Leaf className="w-5 h-5 text-emerald-500" />}
              variant="success"
              testId="kpi-esg"
            />
            <KpiCard
              title="Risk Index"
              value={latestKpi?.riskIndex?.toFixed(1) || "--"}
              change={latestKpi ? -12 : undefined}
              changeLabel="vs last round"
              icon={<AlertTriangle className="w-5 h-5 text-orange-500" />}
              variant="warning"
              testId="kpi-risk"
            />
          </div>

          <div className="grid gap-6 md:grid-cols-2">
            <Card className="hover-elevate">
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                  <BookOpen className="w-5 h-5" />
                  Quick Actions
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <Link href="/student/suppliers">
                  <Button variant="outline" className="w-full justify-start">
                    View Supplier Profiles
                  </Button>
                </Link>
                <Link href="/student/team">
                  <Button variant="outline" className="w-full justify-start">
                    View Team Details
                  </Button>
                </Link>
                <Link href="/student/simulation">
                  <Button variant="outline" className="w-full justify-start">
                    Continue Simulation
                  </Button>
                </Link>
              </CardContent>
            </Card>

            <Card className="hover-elevate">
              <CardHeader>
                <CardTitle className="text-lg">Learning Objectives</CardTitle>
                <CardDescription>Track your progress toward course goals</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="space-y-2">
                    <div className="flex items-center justify-between text-sm">
                      <span>Evaluate suppliers using KPIs</span>
                      <span className="font-medium">In Progress</span>
                    </div>
                    <div className="h-2 rounded-full bg-muted">
                      <div className="h-full w-2/3 rounded-full bg-primary" />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <div className="flex items-center justify-between text-sm">
                      <span>Design agile sourcing strategy</span>
                      <span className="font-medium">Not Started</span>
                    </div>
                    <div className="h-2 rounded-full bg-muted">
                      <div className="h-full w-0 rounded-full bg-primary" />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <div className="flex items-center justify-between text-sm">
                      <span>Balance ESG and cost objectives</span>
                      <span className="font-medium">Not Started</span>
                    </div>
                    <div className="h-2 rounded-full bg-muted">
                      <div className="h-full w-0 rounded-full bg-primary" />
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </>
      ) : (
        <Card className="text-center py-12">
          <CardContent>
            <div className="flex flex-col items-center gap-4">
              <div className="flex items-center justify-center w-16 h-16 rounded-full bg-muted">
                <Users className="w-8 h-8 text-muted-foreground" />
              </div>
              <div className="space-y-2">
                <h3 className="font-semibold text-lg">No Team Assigned</h3>
                <p className="text-muted-foreground max-w-md">
                  You haven't been assigned to a team yet. Please wait for your instructor
                  to add you to a team and session.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
