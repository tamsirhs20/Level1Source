import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { KpiCard } from "@/components/kpi-card";
import { useAuth } from "@/lib/auth-context";
import { Link } from "wouter";
import {
  Users,
  GraduationCap,
  BookOpen,
  Settings,
  Shield,
  UserPlus,
  Server,
  Activity,
} from "lucide-react";
import type { User, Session, Scenario } from "@shared/schema";

export default function AdminDashboard() {
  const { user } = useAuth();

  const { data: allUsers, isLoading: usersLoading } = useQuery<User[]>({
    queryKey: ["/api/admin/users"],
  });

  const { data: sessions } = useQuery<Session[]>({
    queryKey: ["/api/instructor/sessions"],
  });

  const { data: scenarios } = useQuery<Scenario[]>({
    queryKey: ["/api/instructor/scenarios"],
  });

  const students = allUsers?.filter((u) => u.role === "student") || [];
  const instructors = allUsers?.filter((u) => u.role === "instructor") || [];
  const admins = allUsers?.filter((u) => u.role === "admin") || [];

  if (usersLoading) {
    return (
      <div className="p-6 space-y-6">
        <Skeleton className="h-10 w-48" />
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          {[1, 2, 3, 4].map((i) => (
            <Skeleton key={i} className="h-32" />
          ))}
        </div>
        <Skeleton className="h-64" />
      </div>
    );
  }

  const getInitials = (name: string) => {
    return name
      .split(" ")
      .map((n) => n[0])
      .join("")
      .toUpperCase()
      .slice(0, 2);
  };

  return (
    <div className="p-6 space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold" data-testid="text-welcome-admin">
            Admin Dashboard
          </h1>
          <p className="text-muted-foreground">
            System overview and user management
          </p>
        </div>
        <Link href="/admin/users">
          <Button data-testid="button-manage-users">
            <UserPlus className="w-4 h-4 mr-2" />
            Manage Users
          </Button>
        </Link>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <KpiCard
          title="Total Users"
          value={allUsers?.length || 0}
          icon={<Users className="w-5 h-5 text-blue-500" />}
          testId="kpi-total-users"
        />
        <KpiCard
          title="Students"
          value={students.length}
          icon={<GraduationCap className="w-5 h-5 text-green-500" />}
          testId="kpi-students"
        />
        <KpiCard
          title="Instructors"
          value={instructors.length}
          icon={<BookOpen className="w-5 h-5 text-purple-500" />}
          testId="kpi-instructors"
        />
        <KpiCard
          title="Active Sessions"
          value={sessions?.filter((s) => s.isActive).length || 0}
          icon={<Activity className="w-5 h-5 text-orange-500" />}
          testId="kpi-active-sessions"
        />
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between gap-4">
            <div>
              <CardTitle className="text-lg">Recent Users</CardTitle>
              <CardDescription>Latest registered users</CardDescription>
            </div>
            <Link href="/admin/users">
              <Button variant="ghost" size="sm">View All</Button>
            </Link>
          </CardHeader>
          <CardContent>
            {allUsers && allUsers.length > 0 ? (
              <div className="space-y-3">
                {allUsers.slice(0, 5).map((u) => (
                  <div
                    key={u.id}
                    className="flex items-center justify-between p-3 rounded-lg border"
                  >
                    <div className="flex items-center gap-3">
                      <Avatar className="w-9 h-9">
                        <AvatarFallback className="text-xs">
                          {getInitials(u.name)}
                        </AvatarFallback>
                      </Avatar>
                      <div>
                        <p className="font-medium">{u.name}</p>
                        <p className="text-sm text-muted-foreground">@{u.username}</p>
                      </div>
                    </div>
                    <Badge
                      variant={
                        u.role === "admin"
                          ? "default"
                          : u.role === "instructor"
                          ? "secondary"
                          : "outline"
                      }
                      className="capitalize"
                    >
                      {u.role}
                    </Badge>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-8 text-muted-foreground">
                No users registered yet.
              </div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-lg">System Status</CardTitle>
            <CardDescription>Platform health and statistics</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between p-3 rounded-lg bg-green-500/10">
              <div className="flex items-center gap-3">
                <Server className="w-5 h-5 text-green-500" />
                <span>System Status</span>
              </div>
              <Badge variant="secondary" className="bg-green-500/20 text-green-700 dark:text-green-400">
                Operational
              </Badge>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="p-4 rounded-lg bg-muted/50 text-center">
                <p className="text-2xl font-bold font-mono">{scenarios?.length || 0}</p>
                <p className="text-sm text-muted-foreground">Scenarios</p>
              </div>
              <div className="p-4 rounded-lg bg-muted/50 text-center">
                <p className="text-2xl font-bold font-mono">{sessions?.length || 0}</p>
                <p className="text-sm text-muted-foreground">Sessions</p>
              </div>
            </div>
            <div className="space-y-2">
              <div className="flex items-center justify-between text-sm">
                <span>User Distribution</span>
              </div>
              <div className="flex gap-1 h-4 rounded-full overflow-hidden bg-muted">
                <div
                  className="bg-green-500"
                  style={{ width: `${(students.length / (allUsers?.length || 1)) * 100}%` }}
                />
                <div
                  className="bg-purple-500"
                  style={{ width: `${(instructors.length / (allUsers?.length || 1)) * 100}%` }}
                />
                <div
                  className="bg-blue-500"
                  style={{ width: `${(admins.length / (allUsers?.length || 1)) * 100}%` }}
                />
              </div>
              <div className="flex justify-between text-xs text-muted-foreground">
                <span className="flex items-center gap-1">
                  <div className="w-2 h-2 rounded-full bg-green-500" />
                  Students ({students.length})
                </span>
                <span className="flex items-center gap-1">
                  <div className="w-2 h-2 rounded-full bg-purple-500" />
                  Instructors ({instructors.length})
                </span>
                <span className="flex items-center gap-1">
                  <div className="w-2 h-2 rounded-full bg-blue-500" />
                  Admins ({admins.length})
                </span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Quick Actions</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
            <Link href="/admin/users">
              <Button variant="outline" className="w-full justify-start">
                <Users className="w-4 h-4 mr-2" />
                Manage Users
              </Button>
            </Link>
            <Link href="/admin/settings">
              <Button variant="outline" className="w-full justify-start">
                <Settings className="w-4 h-4 mr-2" />
                System Settings
              </Button>
            </Link>
            <Button variant="outline" className="w-full justify-start">
              <Shield className="w-4 h-4 mr-2" />
              Security Logs
            </Button>
            <Button variant="outline" className="w-full justify-start">
              <Activity className="w-4 h-4 mr-2" />
              System Health
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
