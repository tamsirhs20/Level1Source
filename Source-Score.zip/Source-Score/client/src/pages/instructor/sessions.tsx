import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Switch } from "@/components/ui/switch";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
  FormDescription,
} from "@/components/ui/form";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useAuth } from "@/lib/auth-context";
import {
  Plus,
  Play,
  Pause,
  Users,
  Clock,
  Settings,
  Trash2,
  SkipForward,
} from "lucide-react";
import type { Session, Scenario } from "@shared/schema";

const sessionSchema = z.object({
  name: z.string().min(3, "Name must be at least 3 characters"),
  scenarioId: z.string().min(1, "Select a scenario"),
  maxRounds: z.coerce.number().min(3).max(5),
  isActive: z.boolean().default(true),
});

type SessionFormData = z.infer<typeof sessionSchema>;

export default function SessionsPage() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [isDialogOpen, setIsDialogOpen] = useState(false);

  const { data: sessions, isLoading } = useQuery<Session[]>({
    queryKey: ["/api/instructor/sessions"],
  });

  const { data: scenarios } = useQuery<Scenario[]>({
    queryKey: ["/api/instructor/scenarios"],
  });

  const form = useForm<SessionFormData>({
    resolver: zodResolver(sessionSchema),
    defaultValues: {
      name: "",
      scenarioId: "",
      maxRounds: 4,
      isActive: true,
    },
  });

  const createMutation = useMutation({
    mutationFn: async (data: SessionFormData) => {
      return apiRequest("POST", "/api/sessions", {
        ...data,
        instructorId: user?.id,
        currentRound: 0,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/instructor/sessions"] });
      toast({ title: "Success", description: "Session created successfully" });
      setIsDialogOpen(false);
      form.reset();
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to create session", variant: "destructive" });
    },
  });

  const toggleSessionMutation = useMutation({
    mutationFn: async ({ id, isActive }: { id: string; isActive: boolean }) => {
      return apiRequest("PATCH", `/api/sessions/${id}`, { isActive });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/instructor/sessions"] });
      toast({ title: "Success", description: "Session updated" });
    },
  });

  const advanceRoundMutation = useMutation({
    mutationFn: async (id: string) => {
      return apiRequest("POST", `/api/sessions/${id}/advance`, {});
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/instructor/sessions"] });
      toast({ title: "Success", description: "Advanced to next round" });
    },
  });

  const handleSubmit = (data: SessionFormData) => {
    createMutation.mutate(data);
  };

  if (isLoading) {
    return (
      <div className="p-6 space-y-6">
        <Skeleton className="h-10 w-48" />
        <div className="space-y-4">
          {[1, 2, 3].map((i) => (
            <Skeleton key={i} className="h-32" />
          ))}
        </div>
      </div>
    );
  }

  const activeSessions = sessions?.filter((s) => s.isActive) || [];
  const inactiveSessions = sessions?.filter((s) => !s.isActive) || [];

  return (
    <div className="p-6 space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold">Sessions</h1>
          <p className="text-muted-foreground">
            Manage your simulation lab sessions
          </p>
        </div>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button data-testid="button-create-session">
              <Plus className="w-4 h-4 mr-2" />
              New Session
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Create New Session</DialogTitle>
              <DialogDescription>
                Set up a new lab session for your students
              </DialogDescription>
            </DialogHeader>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-4">
                <FormField
                  control={form.control}
                  name="name"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Session Name</FormLabel>
                      <FormControl>
                        <Input
                          placeholder="e.g., Lab Session Week 5"
                          data-testid="input-session-name"
                          {...field}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="scenarioId"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Scenario</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger data-testid="select-scenario">
                            <SelectValue placeholder="Select a scenario" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {scenarios?.map((scenario) => (
                            <SelectItem key={scenario.id} value={scenario.id}>
                              {scenario.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormDescription>
                        Choose the scenario for this session
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="maxRounds"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Number of Rounds</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={String(field.value)}>
                        <FormControl>
                          <SelectTrigger data-testid="select-rounds">
                            <SelectValue />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="3">3 Rounds (Basic)</SelectItem>
                          <SelectItem value="4">4 Rounds (Standard)</SelectItem>
                          <SelectItem value="5">5 Rounds (With Challenge)</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormDescription>
                        Including practice round
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="isActive"
                  render={({ field }) => (
                    <FormItem className="flex items-center justify-between rounded-lg border p-4">
                      <div className="space-y-0.5">
                        <FormLabel>Start Immediately</FormLabel>
                        <FormDescription>
                          Session will be active for students right away
                        </FormDescription>
                      </div>
                      <FormControl>
                        <Switch
                          checked={field.value}
                          onCheckedChange={field.onChange}
                        />
                      </FormControl>
                    </FormItem>
                  )}
                />

                <div className="flex justify-end gap-2 pt-4">
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => setIsDialogOpen(false)}
                  >
                    Cancel
                  </Button>
                  <Button
                    type="submit"
                    disabled={createMutation.isPending}
                    data-testid="button-save-session"
                  >
                    {createMutation.isPending ? "Creating..." : "Create Session"}
                  </Button>
                </div>
              </form>
            </Form>
          </DialogContent>
        </Dialog>
      </div>

      {activeSessions.length > 0 && (
        <div className="space-y-4">
          <h2 className="text-lg font-semibold flex items-center gap-2">
            <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
            Active Sessions
          </h2>
          <div className="space-y-3">
            {activeSessions.map((session) => {
              const scenario = scenarios?.find((s) => s.id === session.scenarioId);
              return (
                <Card key={session.id} className="hover-elevate">
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between gap-4">
                      <div className="flex items-center gap-4">
                        <div className="flex items-center justify-center w-12 h-12 rounded-lg bg-green-500/10">
                          <Play className="w-6 h-6 text-green-500" />
                        </div>
                        <div>
                          <h3 className="font-semibold">{session.name}</h3>
                          <p className="text-sm text-muted-foreground">
                            {scenario?.name || "Unknown Scenario"}
                          </p>
                        </div>
                      </div>
                      <div className="flex items-center gap-4">
                        <div className="flex items-center gap-2 text-sm">
                          <Clock className="w-4 h-4 text-muted-foreground" />
                          Round {session.currentRound} of {session.maxRounds}
                        </div>
                        <Badge variant="secondary">
                          <Users className="w-3 h-3 mr-1" />
                          0 Teams
                        </Badge>
                        <div className="flex gap-1">
                          <Button
                            variant="outline"
                            size="icon"
                            onClick={() => advanceRoundMutation.mutate(session.id)}
                            disabled={session.currentRound >= (session.maxRounds || 4)}
                            data-testid={`button-advance-${session.id}`}
                          >
                            <SkipForward className="w-4 h-4" />
                          </Button>
                          <Button
                            variant="outline"
                            size="icon"
                            onClick={() =>
                              toggleSessionMutation.mutate({
                                id: session.id,
                                isActive: false,
                              })
                            }
                            data-testid={`button-pause-${session.id}`}
                          >
                            <Pause className="w-4 h-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="icon"
                            data-testid={`button-settings-${session.id}`}
                          >
                            <Settings className="w-4 h-4" />
                          </Button>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>
      )}

      {inactiveSessions.length > 0 && (
        <div className="space-y-4">
          <h2 className="text-lg font-semibold text-muted-foreground">
            Inactive Sessions
          </h2>
          <div className="space-y-3">
            {inactiveSessions.map((session) => {
              const scenario = scenarios?.find((s) => s.id === session.scenarioId);
              return (
                <Card key={session.id} className="opacity-70">
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between gap-4">
                      <div className="flex items-center gap-4">
                        <div className="flex items-center justify-center w-12 h-12 rounded-lg bg-muted">
                          <Pause className="w-6 h-6 text-muted-foreground" />
                        </div>
                        <div>
                          <h3 className="font-semibold">{session.name}</h3>
                          <p className="text-sm text-muted-foreground">
                            {scenario?.name || "Unknown Scenario"}
                          </p>
                        </div>
                      </div>
                      <div className="flex items-center gap-4">
                        <Badge variant="outline">
                          Completed Round {session.currentRound}
                        </Badge>
                        <div className="flex gap-1">
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() =>
                              toggleSessionMutation.mutate({
                                id: session.id,
                                isActive: true,
                              })
                            }
                            data-testid={`button-resume-${session.id}`}
                          >
                            <Play className="w-4 h-4 mr-1" />
                            Resume
                          </Button>
                          <Button
                            variant="ghost"
                            size="icon"
                            data-testid={`button-delete-${session.id}`}
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>
      )}

      {(!sessions || sessions.length === 0) && (
        <Card className="py-12 text-center">
          <CardContent>
            <Play className="w-12 h-12 mx-auto text-muted-foreground mb-4" />
            <h3 className="font-semibold text-lg">No Sessions Yet</h3>
            <p className="text-muted-foreground mt-2 mb-4">
              Create your first session to start a simulation with your students.
            </p>
            <Button onClick={() => setIsDialogOpen(true)}>
              <Plus className="w-4 h-4 mr-2" />
              Create Session
            </Button>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
