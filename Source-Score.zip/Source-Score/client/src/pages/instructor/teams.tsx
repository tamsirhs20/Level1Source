import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { TeamRole } from "@shared/schema";
import {
  Plus,
  Users,
  UserPlus,
  Settings,
  Trash2,
  Building2,
  BarChart3,
  FileText,
  Leaf,
  ClipboardList,
} from "lucide-react";
import type { Team, Session, User, TeamMember } from "@shared/schema";

interface TeamWithDetails extends Team {
  members: (TeamMember & { user: User })[];
  session: Session;
}

const teamSchema = z.object({
  name: z.string().min(2, "Name must be at least 2 characters"),
  sessionId: z.string().min(1, "Select a session"),
});

const memberSchema = z.object({
  userId: z.string().min(1, "Select a student"),
  teamRole: z.string().min(1, "Select a role"),
});

type TeamFormData = z.infer<typeof teamSchema>;
type MemberFormData = z.infer<typeof memberSchema>;

const roleInfo: Record<string, { label: string; icon: React.ElementType; color: string }> = {
  [TeamRole.STRATEGIC_SOURCING_MANAGER]: { label: "Strategic Sourcing Manager", icon: Building2, color: "text-blue-500" },
  [TeamRole.SUPPLIER_EVALUATION_ANALYST]: { label: "Supplier Analyst", icon: BarChart3, color: "text-green-500" },
  [TeamRole.CONTRACT_RISK_MANAGER]: { label: "Contract & Risk Manager", icon: FileText, color: "text-orange-500" },
  [TeamRole.ESG_SUSTAINABILITY_OFFICER]: { label: "ESG Officer", icon: Leaf, color: "text-emerald-500" },
  [TeamRole.REPORTING_ANALYST]: { label: "Reporting Analyst", icon: ClipboardList, color: "text-purple-500" },
};

export default function TeamsPage() {
  const { toast } = useToast();
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [isAddMemberDialogOpen, setIsAddMemberDialogOpen] = useState(false);
  const [selectedTeam, setSelectedTeam] = useState<TeamWithDetails | null>(null);

  const { data: teams, isLoading } = useQuery<TeamWithDetails[]>({
    queryKey: ["/api/instructor/teams"],
  });

  const { data: sessions } = useQuery<Session[]>({
    queryKey: ["/api/instructor/sessions"],
  });

  const { data: students } = useQuery<User[]>({
    queryKey: ["/api/instructor/students"],
  });

  const teamForm = useForm<TeamFormData>({
    resolver: zodResolver(teamSchema),
    defaultValues: { name: "", sessionId: "" },
  });

  const memberForm = useForm<MemberFormData>({
    resolver: zodResolver(memberSchema),
    defaultValues: { userId: "", teamRole: "" },
  });

  const createTeamMutation = useMutation({
    mutationFn: async (data: TeamFormData) => {
      return apiRequest("POST", "/api/teams", { ...data, currentRound: 0 });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/instructor/teams"] });
      toast({ title: "Success", description: "Team created" });
      setIsCreateDialogOpen(false);
      teamForm.reset();
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to create team", variant: "destructive" });
    },
  });

  const addMemberMutation = useMutation({
    mutationFn: async (data: MemberFormData & { teamId: string }) => {
      return apiRequest("POST", "/api/team-members", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/instructor/teams"] });
      toast({ title: "Success", description: "Member added to team" });
      setIsAddMemberDialogOpen(false);
      memberForm.reset();
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to add member", variant: "destructive" });
    },
  });

  const handleCreateTeam = (data: TeamFormData) => {
    createTeamMutation.mutate(data);
  };

  const handleAddMember = (data: MemberFormData) => {
    if (selectedTeam) {
      addMemberMutation.mutate({ ...data, teamId: selectedTeam.id });
    }
  };

  const getInitials = (name: string) => {
    return name
      .split(" ")
      .map((n) => n[0])
      .join("")
      .toUpperCase()
      .slice(0, 2);
  };

  if (isLoading) {
    return (
      <div className="p-6 space-y-6">
        <Skeleton className="h-10 w-48" />
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {[1, 2, 3].map((i) => (
            <Skeleton key={i} className="h-64" />
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold">Teams</h1>
          <p className="text-muted-foreground">
            Manage student teams and role assignments
          </p>
        </div>
        <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
          <DialogTrigger asChild>
            <Button data-testid="button-create-team">
              <Plus className="w-4 h-4 mr-2" />
              Create Team
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Create New Team</DialogTitle>
              <DialogDescription>
                Create a team and assign students to it
              </DialogDescription>
            </DialogHeader>
            <Form {...teamForm}>
              <form onSubmit={teamForm.handleSubmit(handleCreateTeam)} className="space-y-4">
                <FormField
                  control={teamForm.control}
                  name="name"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Team Name</FormLabel>
                      <FormControl>
                        <Input
                          placeholder="e.g., Team Alpha"
                          data-testid="input-team-name"
                          {...field}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={teamForm.control}
                  name="sessionId"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Session</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger data-testid="select-team-session">
                            <SelectValue placeholder="Select a session" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {sessions?.map((session) => (
                            <SelectItem key={session.id} value={session.id}>
                              {session.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <div className="flex justify-end gap-2 pt-4">
                  <Button type="button" variant="outline" onClick={() => setIsCreateDialogOpen(false)}>
                    Cancel
                  </Button>
                  <Button type="submit" disabled={createTeamMutation.isPending}>
                    {createTeamMutation.isPending ? "Creating..." : "Create Team"}
                  </Button>
                </div>
              </form>
            </Form>
          </DialogContent>
        </Dialog>
      </div>

      {teams && teams.length > 0 ? (
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {teams.map((team) => (
            <Card key={team.id} className="hover-elevate">
              <CardHeader className="pb-3">
                <div className="flex items-start justify-between gap-2">
                  <div className="flex items-center gap-3">
                    <div className="flex items-center justify-center w-10 h-10 rounded-md bg-primary/10">
                      <Users className="w-5 h-5 text-primary" />
                    </div>
                    <div>
                      <CardTitle className="text-base">{team.name}</CardTitle>
                      <p className="text-sm text-muted-foreground">
                        {team.session?.name || "No session"}
                      </p>
                    </div>
                  </div>
                  <Badge variant="outline">Round {team.currentRound}</Badge>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center gap-2">
                  <div className="flex -space-x-2">
                    {team.members?.slice(0, 4).map((member) => (
                      <Avatar key={member.id} className="w-8 h-8 border-2 border-background">
                        <AvatarFallback className="text-xs">
                          {getInitials(member.user.name)}
                        </AvatarFallback>
                      </Avatar>
                    ))}
                  </div>
                  <span className="text-sm text-muted-foreground">
                    {team.members?.length || 0} members
                  </span>
                </div>

                <div className="space-y-2">
                  {team.members?.map((member) => {
                    const role = roleInfo[member.teamRole];
                    const IconComponent = role?.icon || Users;
                    return (
                      <div key={member.id} className="flex items-center gap-2 text-sm">
                        <IconComponent className={`w-4 h-4 ${role?.color || "text-muted-foreground"}`} />
                        <span className="truncate">{member.user.name}</span>
                        <Badge variant="secondary" className="ml-auto text-xs">
                          {role?.label?.split(" ")[0] || member.teamRole}
                        </Badge>
                      </div>
                    );
                  })}
                </div>

                <div className="flex gap-2 pt-2">
                  <Button
                    variant="outline"
                    size="sm"
                    className="flex-1"
                    onClick={() => {
                      setSelectedTeam(team);
                      setIsAddMemberDialogOpen(true);
                    }}
                    data-testid={`button-add-member-${team.id}`}
                  >
                    <UserPlus className="w-4 h-4 mr-1" />
                    Add Member
                  </Button>
                  <Button variant="ghost" size="icon" data-testid={`button-settings-team-${team.id}`}>
                    <Settings className="w-4 h-4" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : (
        <Card className="py-12 text-center">
          <CardContent>
            <Users className="w-12 h-12 mx-auto text-muted-foreground mb-4" />
            <h3 className="font-semibold text-lg">No Teams Yet</h3>
            <p className="text-muted-foreground mt-2 mb-4">
              Create teams and assign students to start the simulation.
            </p>
            <Button onClick={() => setIsCreateDialogOpen(true)}>
              <Plus className="w-4 h-4 mr-2" />
              Create Team
            </Button>
          </CardContent>
        </Card>
      )}

      <Dialog open={isAddMemberDialogOpen} onOpenChange={setIsAddMemberDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Add Team Member</DialogTitle>
            <DialogDescription>
              Add a student to {selectedTeam?.name}
            </DialogDescription>
          </DialogHeader>
          <Form {...memberForm}>
            <form onSubmit={memberForm.handleSubmit(handleAddMember)} className="space-y-4">
              <FormField
                control={memberForm.control}
                name="userId"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Student</FormLabel>
                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                      <FormControl>
                        <SelectTrigger data-testid="select-student">
                          <SelectValue placeholder="Select a student" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {students?.map((student) => (
                          <SelectItem key={student.id} value={student.id}>
                            {student.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={memberForm.control}
                name="teamRole"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Role</FormLabel>
                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                      <FormControl>
                        <SelectTrigger data-testid="select-role">
                          <SelectValue placeholder="Select a role" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {Object.entries(roleInfo).map(([key, info]) => (
                          <SelectItem key={key} value={key}>
                            {info.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <div className="flex justify-end gap-2 pt-4">
                <Button type="button" variant="outline" onClick={() => setIsAddMemberDialogOpen(false)}>
                  Cancel
                </Button>
                <Button type="submit" disabled={addMemberMutation.isPending}>
                  {addMemberMutation.isPending ? "Adding..." : "Add Member"}
                </Button>
              </div>
            </form>
          </Form>
        </DialogContent>
      </Dialog>
    </div>
  );
}
