import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { KpiCard } from "@/components/kpi-card";
import { TeamCard } from "@/components/team-card";
import { useAuth } from "@/lib/auth-context";
import { Link } from "wouter";
import {
  Users,
  BookOpen,
  Play,
  BarChart3,
  Plus,
  Settings,
  Clock,
  TrendingUp,
} from "lucide-react";
import type { Session, Team, Scenario } from "@shared/schema";

export default function InstructorDashboard() {
  const { user } = useAuth();

  const { data: sessions, isLoading: sessionsLoading } = useQuery<Session[]>({
    queryKey: ["/api/instructor/sessions"],
  });

  const { data: teams, isLoading: teamsLoading } = useQuery<Team[]>({
    queryKey: ["/api/instructor/teams"],
  });

  const { data: scenarios } = useQuery<Scenario[]>({
    queryKey: ["/api/instructor/scenarios"],
  });

  const activeSessions = sessions?.filter((s) => s.isActive) || [];
  const totalStudents = teams?.reduce((sum, t) => sum + 4, 0) || 0; // Placeholder

  if (sessionsLoading || teamsLoading) {
    return (
      <div className="p-6 space-y-6">
        <Skeleton className="h-10 w-48" />
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          {[1, 2, 3, 4].map((i) => (
            <Skeleton key={i} className="h-32" />
          ))}
        </div>
        <Skeleton className="h-64" />
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold" data-testid="text-welcome-instructor">
            Welcome, {user?.name}
          </h1>
          <p className="text-muted-foreground">
            Manage your SCOR Source simulation sessions
          </p>
        </div>
        <div className="flex gap-2">
          <Link href="/instructor/scenarios">
            <Button variant="outline" data-testid="button-manage-scenarios">
              <BookOpen className="w-4 h-4 mr-2" />
              Scenarios
            </Button>
          </Link>
          <Link href="/instructor/sessions">
            <Button data-testid="button-new-session">
              <Plus className="w-4 h-4 mr-2" />
              New Session
            </Button>
          </Link>
        </div>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <KpiCard
          title="Active Sessions"
          value={activeSessions.length}
          icon={<Play className="w-5 h-5 text-green-500" />}
          testId="kpi-active-sessions"
        />
        <KpiCard
          title="Total Teams"
          value={teams?.length || 0}
          icon={<Users className="w-5 h-5 text-blue-500" />}
          testId="kpi-total-teams"
        />
        <KpiCard
          title="Total Students"
          value={totalStudents}
          icon={<TrendingUp className="w-5 h-5 text-purple-500" />}
          testId="kpi-total-students"
        />
        <KpiCard
          title="Scenarios"
          value={scenarios?.length || 0}
          icon={<BookOpen className="w-5 h-5 text-orange-500" />}
          testId="kpi-scenarios"
        />
      </div>

      {activeSessions.length > 0 && (
        <Card>
          <CardHeader className="flex flex-row items-center justify-between gap-4">
            <div>
              <CardTitle className="text-lg">Active Sessions</CardTitle>
              <CardDescription>Currently running simulation sessions</CardDescription>
            </div>
            <Badge variant="outline" className="text-green-500 border-green-500">
              <div className="w-2 h-2 rounded-full bg-green-500 mr-2 animate-pulse" />
              Live
            </Badge>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {activeSessions.map((session) => (
                <div
                  key={session.id}
                  className="flex items-center justify-between p-4 rounded-lg border hover-elevate"
                >
                  <div className="flex items-center gap-4">
                    <div className="flex items-center justify-center w-10 h-10 rounded-md bg-primary/10">
                      <Play className="w-5 h-5 text-primary" />
                    </div>
                    <div>
                      <p className="font-medium">{session.name}</p>
                      <p className="text-sm text-muted-foreground">
                        Round {session.currentRound} of {session.maxRounds}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <Badge variant="secondary">
                      <Clock className="w-3 h-3 mr-1" />
                      In Progress
                    </Badge>
                    <Link href={`/instructor/sessions/${session.id}`}>
                      <Button variant="outline" size="sm">
                        <Settings className="w-4 h-4 mr-1" />
                        Manage
                      </Button>
                    </Link>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      <div className="grid gap-6 lg:grid-cols-2">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between gap-4">
            <div>
              <CardTitle className="text-lg">Recent Teams</CardTitle>
              <CardDescription>Teams participating in your sessions</CardDescription>
            </div>
            <Link href="/instructor/teams">
              <Button variant="ghost" size="sm">View All</Button>
            </Link>
          </CardHeader>
          <CardContent>
            {teams && teams.length > 0 ? (
              <div className="grid gap-4 sm:grid-cols-2">
                {teams.slice(0, 4).map((team) => (
                  <div
                    key={team.id}
                    className="p-4 rounded-lg border hover-elevate cursor-pointer"
                  >
                    <div className="flex items-center gap-3">
                      <div className="flex items-center justify-center w-10 h-10 rounded-md bg-muted">
                        <Users className="w-5 h-5 text-muted-foreground" />
                      </div>
                      <div>
                        <p className="font-medium">{team.name}</p>
                        <p className="text-sm text-muted-foreground">
                          Round {team.currentRound}
                        </p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-8 text-muted-foreground">
                No teams created yet. Create a session to add teams.
              </div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between gap-4">
            <div>
              <CardTitle className="text-lg">Quick Actions</CardTitle>
              <CardDescription>Common instructor tasks</CardDescription>
            </div>
          </CardHeader>
          <CardContent className="space-y-3">
            <Link href="/instructor/scenarios">
              <Button variant="outline" className="w-full justify-start">
                <BookOpen className="w-4 h-4 mr-2" />
                Create New Scenario
              </Button>
            </Link>
            <Link href="/instructor/sessions">
              <Button variant="outline" className="w-full justify-start">
                <Play className="w-4 h-4 mr-2" />
                Start New Session
              </Button>
            </Link>
            <Link href="/instructor/teams">
              <Button variant="outline" className="w-full justify-start">
                <Users className="w-4 h-4 mr-2" />
                Manage Teams
              </Button>
            </Link>
            <Link href="/instructor/analytics">
              <Button variant="outline" className="w-full justify-start">
                <BarChart3 className="w-4 h-4 mr-2" />
                View Analytics
              </Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
