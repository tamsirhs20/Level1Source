import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
  FormDescription,
} from "@/components/ui/form";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useAuth } from "@/lib/auth-context";
import {
  Plus,
  BookOpen,
  Edit,
  Trash2,
  Copy,
  Factory,
  ShoppingCart,
  Cpu,
} from "lucide-react";
import type { Scenario, InsertScenario } from "@shared/schema";

const scenarioSchema = z.object({
  name: z.string().min(3, "Name must be at least 3 characters"),
  description: z.string().optional(),
  productCategory: z.string().min(1, "Select a product category"),
  demandPattern: z.string().min(1, "Select a demand pattern"),
  targetReliability: z.coerce.number().min(0).max(100).optional(),
  targetMaxCost: z.coerce.number().min(0).optional(),
  targetMinEsg: z.coerce.number().min(0).max(100).optional(),
  isTemplate: z.boolean().default(false),
});

type ScenarioFormData = z.infer<typeof scenarioSchema>;

const categoryIcons: Record<string, React.ReactNode> = {
  electronics: <Cpu className="w-5 h-5" />,
  fmcg: <ShoppingCart className="w-5 h-5" />,
  manufacturing: <Factory className="w-5 h-5" />,
};

export default function ScenariosPage() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingScenario, setEditingScenario] = useState<Scenario | null>(null);

  const { data: scenarios, isLoading } = useQuery<Scenario[]>({
    queryKey: ["/api/instructor/scenarios"],
  });

  const form = useForm<ScenarioFormData>({
    resolver: zodResolver(scenarioSchema),
    defaultValues: {
      name: "",
      description: "",
      productCategory: "",
      demandPattern: "stable",
      targetReliability: 85,
      targetMaxCost: 100000,
      targetMinEsg: 60,
      isTemplate: false,
    },
  });

  const createMutation = useMutation({
    mutationFn: async (data: ScenarioFormData) => {
      return apiRequest("POST", "/api/scenarios", {
        ...data,
        instructorId: user?.id,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/instructor/scenarios"] });
      toast({ title: "Success", description: "Scenario created successfully" });
      setIsDialogOpen(false);
      form.reset();
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to create scenario", variant: "destructive" });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: string) => {
      return apiRequest("DELETE", `/api/scenarios/${id}`, {});
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/instructor/scenarios"] });
      toast({ title: "Success", description: "Scenario deleted" });
    },
  });

  const handleSubmit = (data: ScenarioFormData) => {
    createMutation.mutate(data);
  };

  const openEditDialog = (scenario: Scenario) => {
    setEditingScenario(scenario);
    form.reset({
      name: scenario.name,
      description: scenario.description || "",
      productCategory: scenario.productCategory,
      demandPattern: scenario.demandPattern,
      targetReliability: scenario.targetReliability || 85,
      targetMaxCost: scenario.targetMaxCost || 100000,
      targetMinEsg: scenario.targetMinEsg || 60,
      isTemplate: scenario.isTemplate || false,
    });
    setIsDialogOpen(true);
  };

  if (isLoading) {
    return (
      <div className="p-6 space-y-6">
        <Skeleton className="h-10 w-48" />
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {[1, 2, 3].map((i) => (
            <Skeleton key={i} className="h-48" />
          ))}
        </div>
      </div>
    );
  }

  const templates = scenarios?.filter((s) => s.isTemplate) || [];
  const userScenarios = scenarios?.filter((s) => !s.isTemplate && s.instructorId === user?.id) || [];

  return (
    <div className="p-6 space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold">Scenarios</h1>
          <p className="text-muted-foreground">
            Create and manage SCOR Source simulation scenarios
          </p>
        </div>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button data-testid="button-create-scenario">
              <Plus className="w-4 h-4 mr-2" />
              Create Scenario
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>
                {editingScenario ? "Edit Scenario" : "Create New Scenario"}
              </DialogTitle>
              <DialogDescription>
                Configure the procurement scenario for your simulation session
              </DialogDescription>
            </DialogHeader>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-4">
                <FormField
                  control={form.control}
                  name="name"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Scenario Name</FormLabel>
                      <FormControl>
                        <Input
                          placeholder="e.g., Global Electronics Sourcing"
                          data-testid="input-scenario-name"
                          {...field}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="description"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Description</FormLabel>
                      <FormControl>
                        <Textarea
                          placeholder="Describe the scenario context and objectives..."
                          data-testid="input-scenario-description"
                          {...field}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <div className="grid gap-4 sm:grid-cols-2">
                  <FormField
                    control={form.control}
                    name="productCategory"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Product Category</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <FormControl>
                            <SelectTrigger data-testid="select-product-category">
                              <SelectValue placeholder="Select category" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="electronics">Electronics</SelectItem>
                            <SelectItem value="fmcg">FMCG (Fast Moving Consumer Goods)</SelectItem>
                            <SelectItem value="manufacturing">Manufacturing Parts</SelectItem>
                            <SelectItem value="automotive">Automotive Components</SelectItem>
                            <SelectItem value="pharmaceutical">Pharmaceutical</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="demandPattern"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Demand Pattern</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <FormControl>
                            <SelectTrigger data-testid="select-demand-pattern">
                              <SelectValue placeholder="Select pattern" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="stable">Stable</SelectItem>
                            <SelectItem value="fluctuating">Fluctuating</SelectItem>
                            <SelectItem value="seasonal">Seasonal</SelectItem>
                            <SelectItem value="growing">Growing</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <div className="grid gap-4 sm:grid-cols-3">
                  <FormField
                    control={form.control}
                    name="targetReliability"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Target Reliability (%)</FormLabel>
                        <FormControl>
                          <Input
                            type="number"
                            min={0}
                            max={100}
                            data-testid="input-target-reliability"
                            {...field}
                          />
                        </FormControl>
                        <FormDescription className="text-xs">Min. on-time delivery</FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="targetMaxCost"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Max Cost ($)</FormLabel>
                        <FormControl>
                          <Input
                            type="number"
                            min={0}
                            data-testid="input-target-cost"
                            {...field}
                          />
                        </FormControl>
                        <FormDescription className="text-xs">Total procurement budget</FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="targetMinEsg"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Min ESG Score</FormLabel>
                        <FormControl>
                          <Input
                            type="number"
                            min={0}
                            max={100}
                            data-testid="input-target-esg"
                            {...field}
                          />
                        </FormControl>
                        <FormDescription className="text-xs">Minimum sustainability</FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <div className="flex justify-end gap-2 pt-4">
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => {
                      setIsDialogOpen(false);
                      setEditingScenario(null);
                      form.reset();
                    }}
                  >
                    Cancel
                  </Button>
                  <Button
                    type="submit"
                    disabled={createMutation.isPending}
                    data-testid="button-save-scenario"
                  >
                    {createMutation.isPending ? "Saving..." : "Save Scenario"}
                  </Button>
                </div>
              </form>
            </Form>
          </DialogContent>
        </Dialog>
      </div>

      {templates.length > 0 && (
        <div className="space-y-4">
          <h2 className="text-lg font-semibold">Template Scenarios</h2>
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {templates.map((scenario) => (
              <Card key={scenario.id} className="hover-elevate">
                <CardHeader className="pb-3">
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex items-center gap-3">
                      <div className="flex items-center justify-center w-10 h-10 rounded-md bg-primary/10">
                        {categoryIcons[scenario.productCategory] || <BookOpen className="w-5 h-5" />}
                      </div>
                      <div>
                        <CardTitle className="text-base">{scenario.name}</CardTitle>
                        <Badge variant="secondary" className="mt-1">Template</Badge>
                      </div>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground mb-4">
                    {scenario.description || "No description provided"}
                  </p>
                  <div className="flex gap-2">
                    <Badge variant="outline" className="capitalize">
                      {scenario.productCategory}
                    </Badge>
                    <Badge variant="outline" className="capitalize">
                      {scenario.demandPattern}
                    </Badge>
                  </div>
                  <Button variant="outline" size="sm" className="w-full mt-4">
                    <Copy className="w-4 h-4 mr-2" />
                    Use Template
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      )}

      <div className="space-y-4">
        <h2 className="text-lg font-semibold">My Scenarios</h2>
        {userScenarios.length > 0 ? (
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {userScenarios.map((scenario) => (
              <Card key={scenario.id} className="hover-elevate">
                <CardHeader className="pb-3">
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex items-center gap-3">
                      <div className="flex items-center justify-center w-10 h-10 rounded-md bg-muted">
                        {categoryIcons[scenario.productCategory] || <BookOpen className="w-5 h-5" />}
                      </div>
                      <CardTitle className="text-base">{scenario.name}</CardTitle>
                    </div>
                    <div className="flex gap-1">
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => openEditDialog(scenario)}
                        data-testid={`button-edit-${scenario.id}`}
                      >
                        <Edit className="w-4 h-4" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => deleteMutation.mutate(scenario.id)}
                        data-testid={`button-delete-${scenario.id}`}
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground mb-4">
                    {scenario.description || "No description provided"}
                  </p>
                  <div className="flex flex-wrap gap-2">
                    <Badge variant="outline" className="capitalize">
                      {scenario.productCategory}
                    </Badge>
                    <Badge variant="outline" className="capitalize">
                      {scenario.demandPattern}
                    </Badge>
                  </div>
                  <div className="grid grid-cols-3 gap-2 mt-4 text-center">
                    <div className="p-2 rounded-md bg-muted/50">
                      <p className="text-xs text-muted-foreground">Reliability</p>
                      <p className="font-mono font-semibold">{scenario.targetReliability}%</p>
                    </div>
                    <div className="p-2 rounded-md bg-muted/50">
                      <p className="text-xs text-muted-foreground">Max Cost</p>
                      <p className="font-mono font-semibold">${(scenario.targetMaxCost || 0) / 1000}k</p>
                    </div>
                    <div className="p-2 rounded-md bg-muted/50">
                      <p className="text-xs text-muted-foreground">Min ESG</p>
                      <p className="font-mono font-semibold">{scenario.targetMinEsg}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : (
          <Card className="py-12 text-center">
            <CardContent>
              <BookOpen className="w-12 h-12 mx-auto text-muted-foreground mb-4" />
              <h3 className="font-semibold text-lg">No Scenarios Yet</h3>
              <p className="text-muted-foreground mt-2 mb-4">
                Create your first scenario or use a template to get started.
              </p>
              <Button onClick={() => setIsDialogOpen(true)}>
                <Plus className="w-4 h-4 mr-2" />
                Create Scenario
              </Button>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
