import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { KpiCard } from "@/components/kpi-card";
import {
  BarChart3,
  Download,
  Users,
  TrendingUp,
  Target,
  Award,
  Clock,
  DollarSign,
  Leaf,
  AlertTriangle,
} from "lucide-react";
import type { Session, Team, KpiResult } from "@shared/schema";
import { useState } from "react";

export default function AnalyticsPage() {
  const [selectedSession, setSelectedSession] = useState<string>("all");

  const { data: sessions, isLoading: sessionsLoading } = useQuery<Session[]>({
    queryKey: ["/api/instructor/sessions"],
  });

  const { data: teams } = useQuery<Team[]>({
    queryKey: ["/api/instructor/teams"],
  });

  const { data: kpiResults } = useQuery<KpiResult[]>({
    queryKey: ["/api/instructor/kpi-results"],
  });

  if (sessionsLoading) {
    return (
      <div className="p-6 space-y-6">
        <Skeleton className="h-10 w-48" />
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          {[1, 2, 3, 4].map((i) => (
            <Skeleton key={i} className="h-32" />
          ))}
        </div>
        <Skeleton className="h-96" />
      </div>
    );
  }

  const avgReliability = kpiResults?.length
    ? kpiResults.reduce((sum, k) => sum + k.reliabilityScore, 0) / kpiResults.length
    : 0;
  const avgCost = kpiResults?.length
    ? kpiResults.reduce((sum, k) => sum + k.totalCost, 0) / kpiResults.length
    : 0;
  const avgEsg = kpiResults?.length
    ? kpiResults.reduce((sum, k) => sum + k.esgScore, 0) / kpiResults.length
    : 0;
  const avgRisk = kpiResults?.length
    ? kpiResults.reduce((sum, k) => sum + k.riskIndex, 0) / kpiResults.length
    : 0;

  return (
    <div className="p-6 space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold">Learning Analytics</h1>
          <p className="text-muted-foreground">
            Track student performance and learning outcomes
          </p>
        </div>
        <div className="flex items-center gap-3">
          <Select value={selectedSession} onValueChange={setSelectedSession}>
            <SelectTrigger className="w-[200px]" data-testid="select-session-filter">
              <SelectValue placeholder="Filter by session" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Sessions</SelectItem>
              {sessions?.map((session) => (
                <SelectItem key={session.id} value={session.id}>
                  {session.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Button variant="outline" data-testid="button-export">
            <Download className="w-4 h-4 mr-2" />
            Export CSV
          </Button>
        </div>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <KpiCard
          title="Avg. Reliability"
          value={avgReliability.toFixed(0)}
          unit="%"
          icon={<TrendingUp className="w-5 h-5 text-blue-500" />}
          variant="default"
          testId="analytics-reliability"
        />
        <KpiCard
          title="Avg. Total Cost"
          value={`$${(avgCost / 1000).toFixed(0)}k`}
          icon={<DollarSign className="w-5 h-5 text-green-500" />}
          variant="default"
          testId="analytics-cost"
        />
        <KpiCard
          title="Avg. ESG Score"
          value={avgEsg.toFixed(0)}
          unit="/100"
          icon={<Leaf className="w-5 h-5 text-emerald-500" />}
          variant="success"
          testId="analytics-esg"
        />
        <KpiCard
          title="Avg. Risk Index"
          value={avgRisk.toFixed(1)}
          icon={<AlertTriangle className="w-5 h-5 text-orange-500" />}
          variant="warning"
          testId="analytics-risk"
        />
      </div>

      <Tabs defaultValue="overview" className="space-y-4">
        <TabsList>
          <TabsTrigger value="overview" data-testid="tab-overview">
            <BarChart3 className="w-4 h-4 mr-2" />
            Overview
          </TabsTrigger>
          <TabsTrigger value="teams" data-testid="tab-teams">
            <Users className="w-4 h-4 mr-2" />
            Team Performance
          </TabsTrigger>
          <TabsTrigger value="learning" data-testid="tab-learning">
            <Target className="w-4 h-4 mr-2" />
            Learning Outcomes
          </TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-4">
          <div className="grid gap-6 lg:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Performance Distribution</CardTitle>
                <CardDescription>Team performance across key metrics</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-3">
                  <div className="flex items-center justify-between text-sm">
                    <span>Reliability Achievement</span>
                    <span className="font-mono font-medium">{avgReliability.toFixed(0)}%</span>
                  </div>
                  <Progress value={avgReliability} className="h-3" />
                </div>
                <div className="space-y-3">
                  <div className="flex items-center justify-between text-sm">
                    <span>Cost Optimization</span>
                    <span className="font-mono font-medium">72%</span>
                  </div>
                  <Progress value={72} className="h-3" />
                </div>
                <div className="space-y-3">
                  <div className="flex items-center justify-between text-sm">
                    <span>ESG Compliance</span>
                    <span className="font-mono font-medium">{avgEsg.toFixed(0)}%</span>
                  </div>
                  <Progress value={avgEsg} className="h-3" />
                </div>
                <div className="space-y-3">
                  <div className="flex items-center justify-between text-sm">
                    <span>Risk Management</span>
                    <span className="font-mono font-medium">68%</span>
                  </div>
                  <Progress value={68} className="h-3" />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Session Summary</CardTitle>
                <CardDescription>Active sessions and participation</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="p-4 rounded-lg bg-muted/50 text-center">
                    <p className="text-3xl font-bold font-mono">{sessions?.length || 0}</p>
                    <p className="text-sm text-muted-foreground">Total Sessions</p>
                  </div>
                  <div className="p-4 rounded-lg bg-muted/50 text-center">
                    <p className="text-3xl font-bold font-mono">{teams?.length || 0}</p>
                    <p className="text-sm text-muted-foreground">Total Teams</p>
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="p-4 rounded-lg bg-muted/50 text-center">
                    <p className="text-3xl font-bold font-mono">{(teams?.length || 0) * 4}</p>
                    <p className="text-sm text-muted-foreground">Students</p>
                  </div>
                  <div className="p-4 rounded-lg bg-muted/50 text-center">
                    <p className="text-3xl font-bold font-mono">{kpiResults?.length || 0}</p>
                    <p className="text-sm text-muted-foreground">Decisions Recorded</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="teams" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Team Rankings</CardTitle>
              <CardDescription>Performance comparison across teams</CardDescription>
            </CardHeader>
            <CardContent>
              {teams && teams.length > 0 ? (
                <div className="space-y-3">
                  {teams.map((team, index) => (
                    <div
                      key={team.id}
                      className="flex items-center justify-between p-4 rounded-lg border"
                    >
                      <div className="flex items-center gap-4">
                        <div className="flex items-center justify-center w-8 h-8 rounded-full bg-primary/10 text-primary font-bold">
                          {index + 1}
                        </div>
                        <div>
                          <p className="font-medium">{team.name}</p>
                          <p className="text-sm text-muted-foreground">
                            Round {team.currentRound}
                          </p>
                        </div>
                      </div>
                      <div className="flex items-center gap-4">
                        <div className="text-right">
                          <p className="font-mono font-semibold">Score: 82</p>
                          <p className="text-xs text-muted-foreground">Composite</p>
                        </div>
                        <Badge variant={index === 0 ? "default" : "secondary"}>
                          {index === 0 ? "Top" : `#${index + 1}`}
                        </Badge>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8 text-muted-foreground">
                  No team data available yet.
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="learning" className="space-y-4">
          <div className="grid gap-6 lg:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                  <Target className="w-5 h-5" />
                  Learning Outcome Achievement
                </CardTitle>
                <CardDescription>
                  Progress toward course learning objectives
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-medium">LO1: Evaluate Suppliers Using KPIs</p>
                      <p className="text-sm text-muted-foreground">
                        Use reliability, cost, ESG scores in evaluation
                      </p>
                    </div>
                    <Badge variant="secondary">78%</Badge>
                  </div>
                  <Progress value={78} className="h-2" />
                </div>
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-medium">LO2: Design Agile Sourcing Strategy</p>
                      <p className="text-sm text-muted-foreground">
                        Create flexible procurement approaches
                      </p>
                    </div>
                    <Badge variant="secondary">65%</Badge>
                  </div>
                  <Progress value={65} className="h-2" />
                </div>
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-medium">LO3: Balance ESG and Cost</p>
                      <p className="text-sm text-muted-foreground">
                        Achieve sustainability without excessive cost
                      </p>
                    </div>
                    <Badge variant="secondary">72%</Badge>
                  </div>
                  <Progress value={72} className="h-2" />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                  <Award className="w-5 h-5" />
                  SO2 Achievement
                </CardTitle>
                <CardDescription>
                  "Design and evaluate agile, sustainable sourcing strategy"
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="p-6 rounded-lg bg-muted/50 text-center">
                  <p className="text-5xl font-bold font-mono text-primary">72%</p>
                  <p className="text-sm text-muted-foreground mt-2">
                    Average SO2 Achievement Rate
                  </p>
                </div>
                <div className="space-y-2">
                  <div className="flex items-center justify-between p-2 rounded bg-green-500/10">
                    <span className="text-sm">Exceeds Expectations</span>
                    <Badge variant="secondary">15%</Badge>
                  </div>
                  <div className="flex items-center justify-between p-2 rounded bg-blue-500/10">
                    <span className="text-sm">Meets Expectations</span>
                    <Badge variant="secondary">55%</Badge>
                  </div>
                  <div className="flex items-center justify-between p-2 rounded bg-orange-500/10">
                    <span className="text-sm">Approaching</span>
                    <Badge variant="secondary">25%</Badge>
                  </div>
                  <div className="flex items-center justify-between p-2 rounded bg-red-500/10">
                    <span className="text-sm">Needs Improvement</span>
                    <Badge variant="secondary">5%</Badge>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
