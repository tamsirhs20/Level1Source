import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Slider } from "@/components/ui/slider";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip";
import { Info, RotateCcw, Save } from "lucide-react";
import type { KpiWeights, Supplier, SupplierWithScore } from "@shared/schema";

interface ScoringPanelProps {
  weights: KpiWeights;
  suppliers: Supplier[];
  onWeightsChange: (weights: KpiWeights) => void;
  onApplyScoring?: () => void;
  disabled?: boolean;
}

const defaultWeights: KpiWeights = {
  reliability: 25,
  cost: 25,
  esg: 25,
  risk: 25,
};

export function ScoringPanel({
  weights,
  suppliers,
  onWeightsChange,
  onApplyScoring,
  disabled = false,
}: ScoringPanelProps) {
  const [localWeights, setLocalWeights] = useState<KpiWeights>(weights);
  const [totalWeight, setTotalWeight] = useState(100);

  useEffect(() => {
    const total = localWeights.reliability + localWeights.cost + localWeights.esg + localWeights.risk;
    setTotalWeight(total);
  }, [localWeights]);

  const handleWeightChange = (key: keyof KpiWeights, value: number[]) => {
    const newWeights = { ...localWeights, [key]: value[0] };
    setLocalWeights(newWeights);
  };

  const handleApply = () => {
    if (totalWeight === 100) {
      onWeightsChange(localWeights);
      onApplyScoring?.();
    }
  };

  const handleReset = () => {
    setLocalWeights(defaultWeights);
    onWeightsChange(defaultWeights);
  };

  const calculateScore = (supplier: Supplier): number => {
    const reliabilityScore = supplier.onTimeDeliveryRate * 100 * (localWeights.reliability / 100);
    const costScore = (100 - (supplier.unitPrice / 200) * 100) * (localWeights.cost / 100);
    const esgScore =
      ((supplier.esgEnvironmental + supplier.esgSocial + supplier.esgGovernance) / 3) *
      (localWeights.esg / 100);
    const riskScore =
      (supplier.riskLevel === "low" ? 100 : supplier.riskLevel === "medium" ? 50 : 20) *
      (localWeights.risk / 100);
    return reliabilityScore + costScore + esgScore + riskScore;
  };

  const rankedSuppliers = [...suppliers]
    .map((s) => ({ ...s, score: calculateScore(s) }))
    .sort((a, b) => b.score - a.score);

  const isValidTotal = totalWeight === 100;

  return (
    <Card className="h-full" data-testid="scoring-panel">
      <CardHeader className="pb-4">
        <div className="flex items-center justify-between gap-2">
          <div>
            <CardTitle className="text-lg">KPI Scoring Weights</CardTitle>
            <CardDescription>Adjust weights to prioritize supplier attributes</CardDescription>
          </div>
          <Badge variant={isValidTotal ? "secondary" : "destructive"}>
            Total: {totalWeight}%
          </Badge>
        </div>
      </CardHeader>

      <CardContent className="space-y-6">
        <div className="space-y-4">
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <Label className="flex items-center gap-1">
                Reliability
                <Tooltip>
                  <TooltipTrigger asChild>
                    <Info className="w-3 h-3 text-muted-foreground" />
                  </TooltipTrigger>
                  <TooltipContent>
                    On-time delivery rate and defect rate
                  </TooltipContent>
                </Tooltip>
              </Label>
              <span className="text-sm font-mono font-medium w-10 text-right">
                {localWeights.reliability}%
              </span>
            </div>
            <Slider
              value={[localWeights.reliability]}
              onValueChange={(v) => handleWeightChange("reliability", v)}
              max={100}
              step={5}
              disabled={disabled}
              data-testid="slider-reliability"
            />
          </div>

          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <Label className="flex items-center gap-1">
                Cost
                <Tooltip>
                  <TooltipTrigger asChild>
                    <Info className="w-3 h-3 text-muted-foreground" />
                  </TooltipTrigger>
                  <TooltipContent>
                    Unit price, volume discounts, landed cost
                  </TooltipContent>
                </Tooltip>
              </Label>
              <span className="text-sm font-mono font-medium w-10 text-right">
                {localWeights.cost}%
              </span>
            </div>
            <Slider
              value={[localWeights.cost]}
              onValueChange={(v) => handleWeightChange("cost", v)}
              max={100}
              step={5}
              disabled={disabled}
              data-testid="slider-cost"
            />
          </div>

          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <Label className="flex items-center gap-1">
                ESG
                <Tooltip>
                  <TooltipTrigger asChild>
                    <Info className="w-3 h-3 text-muted-foreground" />
                  </TooltipTrigger>
                  <TooltipContent>
                    Environmental, Social, Governance scores
                  </TooltipContent>
                </Tooltip>
              </Label>
              <span className="text-sm font-mono font-medium w-10 text-right">
                {localWeights.esg}%
              </span>
            </div>
            <Slider
              value={[localWeights.esg]}
              onValueChange={(v) => handleWeightChange("esg", v)}
              max={100}
              step={5}
              disabled={disabled}
              data-testid="slider-esg"
            />
          </div>

          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <Label className="flex items-center gap-1">
                Risk
                <Tooltip>
                  <TooltipTrigger asChild>
                    <Info className="w-3 h-3 text-muted-foreground" />
                  </TooltipTrigger>
                  <TooltipContent>
                    Supply risk, country risk, disruption history
                  </TooltipContent>
                </Tooltip>
              </Label>
              <span className="text-sm font-mono font-medium w-10 text-right">
                {localWeights.risk}%
              </span>
            </div>
            <Slider
              value={[localWeights.risk]}
              onValueChange={(v) => handleWeightChange("risk", v)}
              max={100}
              step={5}
              disabled={disabled}
              data-testid="slider-risk"
            />
          </div>
        </div>

        {!isValidTotal && (
          <p className="text-sm text-destructive">
            Weights must total exactly 100%
          </p>
        )}

        <div className="flex gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={handleReset}
            disabled={disabled}
            data-testid="button-reset-weights"
          >
            <RotateCcw className="w-4 h-4 mr-1" />
            Reset
          </Button>
          <Button
            size="sm"
            className="flex-1"
            onClick={handleApply}
            disabled={disabled || !isValidTotal}
            data-testid="button-apply-weights"
          >
            <Save className="w-4 h-4 mr-1" />
            Apply Scoring
          </Button>
        </div>

        {rankedSuppliers.length > 0 && (
          <div className="pt-4 border-t">
            <h4 className="text-sm font-medium mb-3">Preview Rankings</h4>
            <div className="space-y-2">
              {rankedSuppliers.slice(0, 5).map((supplier, index) => (
                <div
                  key={supplier.id}
                  className="flex items-center justify-between p-2 rounded-md bg-muted/50"
                >
                  <div className="flex items-center gap-2">
                    <span className="flex items-center justify-center w-6 h-6 rounded-full bg-primary/10 text-primary text-xs font-bold">
                      {index + 1}
                    </span>
                    <span className="text-sm font-medium truncate max-w-[120px]">
                      {supplier.name}
                    </span>
                  </div>
                  <span className="font-mono font-semibold text-sm">
                    {supplier.score.toFixed(1)}
                  </span>
                </div>
              ))}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
