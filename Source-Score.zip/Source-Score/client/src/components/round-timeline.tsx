import { cn } from "@/lib/utils";
import { Check, Circle, Lock, Play } from "lucide-react";
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip";

interface Round {
  number: number;
  name: string;
  description: string;
  status: "completed" | "current" | "locked" | "available";
}

interface RoundTimelineProps {
  rounds: Round[];
  currentRound: number;
  onRoundClick?: (round: number) => void;
  className?: string;
}

export function RoundTimeline({
  rounds,
  currentRound,
  onRoundClick,
  className,
}: RoundTimelineProps) {
  const getStatusIcon = (status: Round["status"]) => {
    switch (status) {
      case "completed":
        return <Check className="w-4 h-4" />;
      case "current":
        return <Play className="w-4 h-4" />;
      case "locked":
        return <Lock className="w-4 h-4" />;
      default:
        return <Circle className="w-4 h-4" />;
    }
  };

  const getStatusStyles = (status: Round["status"]) => {
    switch (status) {
      case "completed":
        return "bg-green-500 text-white border-green-500";
      case "current":
        return "bg-primary text-primary-foreground border-primary animate-pulse";
      case "locked":
        return "bg-muted text-muted-foreground border-muted";
      default:
        return "bg-background text-foreground border-border";
    }
  };

  return (
    <div className={cn("flex items-center gap-2", className)} data-testid="round-timeline">
      {rounds.map((round, index) => (
        <div key={round.number} className="flex items-center">
          <Tooltip>
            <TooltipTrigger asChild>
              <button
                onClick={() => round.status !== "locked" && onRoundClick?.(round.number)}
                disabled={round.status === "locked"}
                className={cn(
                  "flex items-center justify-center w-10 h-10 rounded-full border-2 transition-all",
                  getStatusStyles(round.status),
                  round.status !== "locked" && "hover:scale-105 cursor-pointer"
                )}
                data-testid={`button-round-${round.number}`}
              >
                {getStatusIcon(round.status)}
              </button>
            </TooltipTrigger>
            <TooltipContent side="bottom" className="max-w-xs">
              <div className="space-y-1">
                <p className="font-semibold">{round.name}</p>
                <p className="text-xs text-muted-foreground">{round.description}</p>
              </div>
            </TooltipContent>
          </Tooltip>
          
          {index < rounds.length - 1 && (
            <div
              className={cn(
                "w-8 h-0.5 mx-1",
                rounds[index + 1].status === "locked"
                  ? "bg-muted"
                  : round.status === "completed"
                  ? "bg-green-500"
                  : "bg-border"
              )}
            />
          )}
        </div>
      ))}
    </div>
  );
}

export const defaultRounds: Round[] = [
  {
    number: 0,
    name: "Practice Round",
    description: "Learn the interface with a simple scenario. No consequences for your decisions.",
    status: "available",
  },
  {
    number: 1,
    name: "Basic Strategic Sourcing",
    description: "Focus on reliability and cost with 3-4 suppliers. Design your initial sourcing strategy.",
    status: "locked",
  },
  {
    number: 2,
    name: "Risk & ESG Sourcing",
    description: "Add risk and ESG dimensions. Handle disruption events and balance sustainability.",
    status: "locked",
  },
  {
    number: 3,
    name: "Agility & Long-Term Strategy",
    description: "High demand variability. Choose long-term contracts and develop suppliers.",
    status: "locked",
  },
  {
    number: 4,
    name: "Challenge Round",
    description: "Extreme scenario: major supplier failure or new ESG regulations. Test your strategy resilience.",
    status: "locked",
  },
];
