import { Link, useLocation } from "wouter";
import {
  LayoutDashboard,
  Users,
  Package,
  Settings,
  BarChart3,
  ClipboardList,
  BookOpen,
  Factory,
  Leaf,
  FileText,
  LogOut,
  GraduationCap,
  Building2,
} from "lucide-react";
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarHeader,
  SidebarFooter,
} from "@/components/ui/sidebar";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/lib/auth-context";
import { UserRole, TeamRole } from "@shared/schema";

const instructorMenuItems = [
  { title: "Dashboard", url: "/instructor", icon: LayoutDashboard },
  { title: "Scenarios", url: "/instructor/scenarios", icon: BookOpen },
  { title: "Sessions", url: "/instructor/sessions", icon: ClipboardList },
  { title: "Teams", url: "/instructor/teams", icon: Users },
  { title: "Analytics", url: "/instructor/analytics", icon: BarChart3 },
];

const studentMenuItems = [
  { title: "Dashboard", url: "/student", icon: LayoutDashboard },
  { title: "Simulation", url: "/student/simulation", icon: Factory },
  { title: "Suppliers", url: "/student/suppliers", icon: Package },
  { title: "My Team", url: "/student/team", icon: Users },
];

const adminMenuItems = [
  { title: "Dashboard", url: "/admin", icon: LayoutDashboard },
  { title: "Users", url: "/admin/users", icon: Users },
  { title: "Settings", url: "/admin/settings", icon: Settings },
];

const teamRoleLabels: Record<string, { label: string; icon: React.ElementType }> = {
  [TeamRole.STRATEGIC_SOURCING_MANAGER]: { label: "Strategic Sourcing Manager", icon: Building2 },
  [TeamRole.SUPPLIER_EVALUATION_ANALYST]: { label: "Supplier Analyst", icon: BarChart3 },
  [TeamRole.CONTRACT_RISK_MANAGER]: { label: "Contract & Risk Manager", icon: FileText },
  [TeamRole.ESG_SUSTAINABILITY_OFFICER]: { label: "ESG Officer", icon: Leaf },
  [TeamRole.REPORTING_ANALYST]: { label: "Reporting Analyst", icon: ClipboardList },
};

interface AppSidebarProps {
  teamRole?: string;
}

export function AppSidebar({ teamRole }: AppSidebarProps) {
  const { user, logout } = useAuth();
  const [location] = useLocation();

  if (!user) return null;

  const getMenuItems = () => {
    switch (user.role) {
      case UserRole.INSTRUCTOR:
        return instructorMenuItems;
      case UserRole.ADMIN:
        return adminMenuItems;
      default:
        return studentMenuItems;
    }
  };

  const menuItems = getMenuItems();
  const roleInfo = teamRole ? teamRoleLabels[teamRole] : null;

  const getInitials = (name: string) => {
    return name
      .split(" ")
      .map((n) => n[0])
      .join("")
      .toUpperCase()
      .slice(0, 2);
  };

  return (
    <Sidebar>
      <SidebarHeader className="p-4 border-b border-sidebar-border">
        <div className="flex items-center gap-3">
          <div className="flex items-center justify-center w-10 h-10 rounded-md bg-primary text-primary-foreground">
            <GraduationCap className="w-6 h-6" />
          </div>
          <div className="flex flex-col">
            <span className="font-semibold text-sm">SCOR Source</span>
            <span className="text-xs text-muted-foreground">Simulation Platform</span>
          </div>
        </div>
      </SidebarHeader>

      <SidebarContent>
        <SidebarGroup>
          <SidebarGroupLabel>Navigation</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {menuItems.map((item) => (
                <SidebarMenuItem key={item.title}>
                  <SidebarMenuButton
                    asChild
                    isActive={location === item.url}
                  >
                    <Link href={item.url} data-testid={`link-${item.title.toLowerCase().replace(/\s+/g, "-")}`}>
                      <item.icon className="w-4 h-4" />
                      <span>{item.title}</span>
                    </Link>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>

        {user.role === UserRole.STUDENT && roleInfo && (
          <SidebarGroup>
            <SidebarGroupLabel>Your Role</SidebarGroupLabel>
            <SidebarGroupContent>
              <div className="px-3 py-2">
                <div className="flex items-center gap-2 p-3 rounded-md bg-sidebar-accent">
                  <roleInfo.icon className="w-4 h-4 text-primary" />
                  <span className="text-sm font-medium">{roleInfo.label}</span>
                </div>
              </div>
            </SidebarGroupContent>
          </SidebarGroup>
        )}
      </SidebarContent>

      <SidebarFooter className="p-4 border-t border-sidebar-border">
        <div className="flex items-center gap-3">
          <Avatar className="w-9 h-9">
            <AvatarFallback className="bg-primary/10 text-primary text-sm">
              {getInitials(user.name)}
            </AvatarFallback>
          </Avatar>
          <div className="flex-1 min-w-0">
            <p className="text-sm font-medium truncate">{user.name}</p>
            <p className="text-xs text-muted-foreground capitalize">{user.role}</p>
          </div>
          <Button
            variant="ghost"
            size="icon"
            onClick={logout}
            data-testid="button-logout"
          >
            <LogOut className="w-4 h-4" />
          </Button>
        </div>
      </SidebarFooter>
    </Sidebar>
  );
}
