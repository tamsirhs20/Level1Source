import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Users, TrendingUp, DollarSign, Leaf, AlertTriangle } from "lucide-react";
import { TeamRole } from "@shared/schema";
import type { TeamWithMembers, KpiResult } from "@shared/schema";
import { cn } from "@/lib/utils";

interface TeamCardProps {
  team: TeamWithMembers;
  latestKpi?: KpiResult;
  onClick?: () => void;
  className?: string;
}

const roleColors: Record<string, string> = {
  [TeamRole.STRATEGIC_SOURCING_MANAGER]: "bg-blue-500/10 text-blue-500",
  [TeamRole.SUPPLIER_EVALUATION_ANALYST]: "bg-green-500/10 text-green-500",
  [TeamRole.CONTRACT_RISK_MANAGER]: "bg-orange-500/10 text-orange-500",
  [TeamRole.ESG_SUSTAINABILITY_OFFICER]: "bg-emerald-500/10 text-emerald-500",
  [TeamRole.REPORTING_ANALYST]: "bg-purple-500/10 text-purple-500",
};

const roleShortNames: Record<string, string> = {
  [TeamRole.STRATEGIC_SOURCING_MANAGER]: "SSM",
  [TeamRole.SUPPLIER_EVALUATION_ANALYST]: "SEA",
  [TeamRole.CONTRACT_RISK_MANAGER]: "CRM",
  [TeamRole.ESG_SUSTAINABILITY_OFFICER]: "ESG",
  [TeamRole.REPORTING_ANALYST]: "RA",
};

export function TeamCard({ team, latestKpi, onClick, className }: TeamCardProps) {
  const getInitials = (name: string) => {
    return name
      .split(" ")
      .map((n) => n[0])
      .join("")
      .toUpperCase()
      .slice(0, 2);
  };

  return (
    <Card
      className={cn("hover-elevate cursor-pointer", className)}
      onClick={onClick}
      data-testid={`card-team-${team.id}`}
    >
      <CardHeader className="pb-3">
        <div className="flex items-start justify-between gap-2">
          <div>
            <CardTitle className="text-base">{team.name}</CardTitle>
            <div className="flex items-center gap-1 mt-1 text-sm text-muted-foreground">
              <Users className="w-3 h-3" />
              <span>{team.members.length} members</span>
            </div>
          </div>
          <Badge variant="outline">Round {team.currentRound}</Badge>
        </div>
      </CardHeader>

      <CardContent className="space-y-4">
        <div className="flex -space-x-2">
          {team.members.slice(0, 5).map((member) => (
            <Avatar
              key={member.id}
              className={cn(
                "w-8 h-8 border-2 border-background",
                roleColors[member.teamRole] || "bg-muted"
              )}
            >
              <AvatarFallback className="text-xs">
                {getInitials(member.user.name)}
              </AvatarFallback>
            </Avatar>
          ))}
          {team.members.length > 5 && (
            <div className="flex items-center justify-center w-8 h-8 rounded-full bg-muted border-2 border-background">
              <span className="text-xs font-medium">+{team.members.length - 5}</span>
            </div>
          )}
        </div>

        <div className="flex flex-wrap gap-1">
          {team.members.map((member) => (
            <Badge
              key={member.id}
              variant="secondary"
              className={cn("text-xs", roleColors[member.teamRole])}
            >
              {roleShortNames[member.teamRole] || member.teamRole}
            </Badge>
          ))}
        </div>

        {latestKpi && (
          <div className="space-y-3 pt-3 border-t">
            <div className="grid grid-cols-2 gap-2">
              <div className="flex items-center gap-2">
                <TrendingUp className="w-4 h-4 text-blue-500" />
                <div>
                  <p className="text-xs text-muted-foreground">Reliability</p>
                  <p className="font-mono font-semibold text-sm">
                    {latestKpi.reliabilityScore.toFixed(0)}%
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <DollarSign className="w-4 h-4 text-green-500" />
                <div>
                  <p className="text-xs text-muted-foreground">Cost</p>
                  <p className="font-mono font-semibold text-sm">
                    ${latestKpi.totalCost.toLocaleString()}
                  </p>
                </div>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-2">
              <div className="flex items-center gap-2">
                <Leaf className="w-4 h-4 text-emerald-500" />
                <div>
                  <p className="text-xs text-muted-foreground">ESG</p>
                  <p className="font-mono font-semibold text-sm">
                    {latestKpi.esgScore.toFixed(0)}
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 text-orange-500" />
                <div>
                  <p className="text-xs text-muted-foreground">Risk</p>
                  <p className="font-mono font-semibold text-sm">
                    {latestKpi.riskIndex.toFixed(1)}
                  </p>
                </div>
              </div>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
