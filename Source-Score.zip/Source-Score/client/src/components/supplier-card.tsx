import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip";
import {
  MapPin,
  Clock,
  DollarSign,
  Leaf,
  AlertTriangle,
  CheckCircle,
  Info,
  TrendingUp,
} from "lucide-react";
import type { Supplier } from "@shared/schema";
import { cn } from "@/lib/utils";

interface SupplierCardProps {
  supplier: Supplier;
  isSelected?: boolean;
  allocation?: number;
  onSelect?: () => void;
  onViewDetails?: () => void;
  showActions?: boolean;
  compositeScore?: number;
}

export function SupplierCard({
  supplier,
  isSelected,
  allocation,
  onSelect,
  onViewDetails,
  showActions = true,
  compositeScore,
}: SupplierCardProps) {
  const getRiskBadgeVariant = (level: string) => {
    switch (level) {
      case "low":
        return "secondary";
      case "medium":
        return "outline";
      case "high":
        return "destructive";
      default:
        return "secondary";
    }
  };

  const getRiskIcon = (level: string) => {
    switch (level) {
      case "low":
        return <CheckCircle className="w-3 h-3" />;
      case "medium":
        return <AlertTriangle className="w-3 h-3" />;
      case "high":
        return <AlertTriangle className="w-3 h-3" />;
      default:
        return null;
    }
  };

  const esgAverage = (supplier.esgEnvironmental + supplier.esgSocial + supplier.esgGovernance) / 3;

  return (
    <Card
      className={cn(
        "transition-all",
        isSelected && "ring-2 ring-primary",
        showActions && "hover-elevate cursor-pointer"
      )}
      onClick={showActions ? onSelect : undefined}
      data-testid={`card-supplier-${supplier.id}`}
    >
      <CardHeader className="flex flex-row items-start justify-between gap-2 pb-2">
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 flex-wrap">
            <h3 className="font-semibold text-base truncate">{supplier.name}</h3>
            <Badge variant={getRiskBadgeVariant(supplier.riskLevel)} className="text-xs">
              {getRiskIcon(supplier.riskLevel)}
              <span className="ml-1 capitalize">{supplier.riskLevel} Risk</span>
            </Badge>
          </div>
          <div className="flex items-center gap-1 mt-1 text-sm text-muted-foreground">
            <MapPin className="w-3 h-3" />
            <span>{supplier.country}</span>
            {supplier.isLocal && (
              <Badge variant="outline" className="ml-1 text-xs">Local</Badge>
            )}
          </div>
        </div>
        {compositeScore !== undefined && (
          <div className="flex flex-col items-end">
            <span className="text-xs text-muted-foreground">Score</span>
            <span className="text-xl font-bold font-mono text-primary">
              {compositeScore.toFixed(1)}
            </span>
          </div>
        )}
      </CardHeader>

      <CardContent className="space-y-4">
        <div className="grid grid-cols-2 gap-3">
          <Tooltip>
            <TooltipTrigger asChild>
              <div className="flex items-center gap-2 p-2 rounded-md bg-muted/50">
                <DollarSign className="w-4 h-4 text-muted-foreground" />
                <div>
                  <p className="text-xs text-muted-foreground">Unit Price</p>
                  <p className="font-mono font-semibold">${supplier.unitPrice}</p>
                </div>
              </div>
            </TooltipTrigger>
            <TooltipContent>
              <p>Volume discount: {supplier.volumeDiscount}%</p>
            </TooltipContent>
          </Tooltip>

          <Tooltip>
            <TooltipTrigger asChild>
              <div className="flex items-center gap-2 p-2 rounded-md bg-muted/50">
                <Clock className="w-4 h-4 text-muted-foreground" />
                <div>
                  <p className="text-xs text-muted-foreground">Lead Time</p>
                  <p className="font-mono font-semibold">{supplier.leadTime} days</p>
                </div>
              </div>
            </TooltipTrigger>
            <TooltipContent>
              <p>Variability: {(supplier.leadTimeVariability * 100).toFixed(0)}%</p>
            </TooltipContent>
          </Tooltip>
        </div>

        <div className="space-y-2">
          <div className="flex items-center justify-between text-sm">
            <span className="flex items-center gap-1 text-muted-foreground">
              <TrendingUp className="w-3 h-3" />
              Reliability
            </span>
            <span className="font-mono font-medium">
              {(supplier.onTimeDeliveryRate * 100).toFixed(0)}%
            </span>
          </div>
          <Progress value={supplier.onTimeDeliveryRate * 100} className="h-2" />
        </div>

        <div className="space-y-2">
          <div className="flex items-center justify-between text-sm">
            <span className="flex items-center gap-1 text-muted-foreground">
              <Leaf className="w-3 h-3" />
              ESG Score
            </span>
            <span className="font-mono font-medium">{esgAverage.toFixed(0)}/100</span>
          </div>
          <div className="flex gap-1">
            <Tooltip>
              <TooltipTrigger asChild>
                <div className="flex-1 h-2 rounded-sm bg-green-500/20">
                  <div
                    className="h-full bg-green-500 rounded-sm"
                    style={{ width: `${supplier.esgEnvironmental}%` }}
                  />
                </div>
              </TooltipTrigger>
              <TooltipContent>Environmental: {supplier.esgEnvironmental}</TooltipContent>
            </Tooltip>
            <Tooltip>
              <TooltipTrigger asChild>
                <div className="flex-1 h-2 rounded-sm bg-blue-500/20">
                  <div
                    className="h-full bg-blue-500 rounded-sm"
                    style={{ width: `${supplier.esgSocial}%` }}
                  />
                </div>
              </TooltipTrigger>
              <TooltipContent>Social: {supplier.esgSocial}</TooltipContent>
            </Tooltip>
            <Tooltip>
              <TooltipTrigger asChild>
                <div className="flex-1 h-2 rounded-sm bg-purple-500/20">
                  <div
                    className="h-full bg-purple-500 rounded-sm"
                    style={{ width: `${supplier.esgGovernance}%` }}
                  />
                </div>
              </TooltipTrigger>
              <TooltipContent>Governance: {supplier.esgGovernance}</TooltipContent>
            </Tooltip>
          </div>
          <div className="flex justify-between text-xs text-muted-foreground">
            <span>E</span>
            <span>S</span>
            <span>G</span>
          </div>
        </div>

        {allocation !== undefined && (
          <div className="flex items-center justify-between p-2 rounded-md bg-primary/10">
            <span className="text-sm font-medium">Volume Allocation</span>
            <span className="font-mono font-bold text-primary">{allocation}%</span>
          </div>
        )}

        {showActions && (
          <div className="flex gap-2 pt-2">
            <Button
              variant={isSelected ? "default" : "outline"}
              className="flex-1"
              onClick={(e) => {
                e.stopPropagation();
                onSelect?.();
              }}
              data-testid={`button-select-supplier-${supplier.id}`}
            >
              {isSelected ? "Selected" : "Select"}
            </Button>
            <Button
              variant="ghost"
              size="icon"
              onClick={(e) => {
                e.stopPropagation();
                onViewDetails?.();
              }}
              data-testid={`button-details-supplier-${supplier.id}`}
            >
              <Info className="w-4 h-4" />
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
