# SCOR Source Simulation Platform

## Overview
A logistics education platform for teaching strategic sourcing, ESG management, and risk assessment through interactive team-based simulations based on the SCOR (Supply Chain Operations Reference) framework.

## Current State
- **Database**: PostgreSQL with Drizzle ORM - fully integrated and seeded with template data
- **Backend**: Express.js with DatabaseStorage implementation
- **Frontend**: React with shadcn/ui, wouter routing, and TanStack Query
- **Authentication**: Session-based with role support (Student, Instructor, Admin)

## Recent Changes
- 2024-12-30: Migrated from MemStorage to DatabaseStorage with PostgreSQL
- Seeded template scenarios (Electronics Sourcing, FMCG Sourcing) and 9 suppliers

## Project Architecture

### Backend (`/server`)
- `index.ts` - Express server setup with automatic database seeding
- `routes.ts` - API endpoints for all CRUD operations
- `storage.ts` - DatabaseStorage class implementing IStorage interface
- `db.ts` - Drizzle database connection pool

### Shared (`/shared`)
- `schema.ts` - Drizzle schema definitions for all 9 tables:
  - users, scenarios, suppliers, sessions, teams, teamMembers, decisions, kpiResults, activityLogs

### Frontend (`/client/src`)
- `/pages` - Role-specific pages (student, instructor, admin dashboards)
- `/components` - Reusable UI components with shadcn/ui
- `/lib/auth-context.tsx` - Authentication context provider

## User Types
1. **Student** - Participates in simulations, evaluates suppliers, makes sourcing decisions
2. **Instructor** - Creates scenarios, manages sessions, views analytics
3. **Admin** - System management, user administration

## Team Roles (for Students)
- Strategic Sourcing Manager
- Supplier Evaluation Analyst
- Contract Risk Manager
- ESG Sustainability Officer
- Reporting Analyst

## Database Commands
- `npm run db:push` - Push schema changes to PostgreSQL
- `npm run db:push --force` - Force push schema changes

## Running the Application
- `npm run dev` - Starts development server on port 5000
