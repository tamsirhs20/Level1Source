# Design Guidelines: SCOR Source Simulation Platform

## Design Approach

**Selected Framework**: Design System Approach - Material Design 3
**Rationale**: This educational simulation platform requires information-dense interfaces, consistent data visualization, and clear role-based navigation. Material Design 3 provides robust components for dashboards, data tables, and interactive educational tools while maintaining professional credibility in academic settings.

**Core Design Principles**:
- Clarity over decoration: Information hierarchy drives all layout decisions
- Role-based differentiation: Each user type (student roles, instructor, admin) gets distinct but consistent layouts
- Data-first visualization: KPIs, metrics, and analytics are primary content
- Progressive disclosure: Complex supplier data and analytics revealed systematically

---

## Typography System

**Font Families**:
- Primary: Inter (headings, UI elements, data labels)
- Secondary: Roboto Mono (numerical data, KPIs, code-like elements)

**Hierarchy**:
- Page Titles: 2xl, bold (role names, section headers)
- Section Headers: xl, semibold (dashboard sections, round titles)
- Data Labels: sm, medium (KPI labels, supplier attributes)
- Body Text: base, regular (descriptions, instructions)
- Numerical Data: lg, mono, semibold (costs, percentages, scores)

---

## Layout System

**Spacing Units**: Tailwind units of 3, 4, 6, and 8
- Component padding: p-4 or p-6
- Section spacing: py-6 or py-8
- Card gaps: gap-4 or gap-6
- Margins: m-3, m-4, or m-6

**Grid Structures**:
- Dashboard: Sidebar (w-64) + Main content area with responsive grid (grid-cols-1 md:grid-cols-2 lg:grid-cols-3)
- Data Tables: Full-width with horizontal scroll on mobile
- Role Panels: 2-column layouts for forms (lg:grid-cols-2)
- Analytics: Flexible grid adapting to chart/metric cards

---

## Component Library

### Navigation
- **Instructor Dashboard**: Top navigation bar with session controls, class switcher, analytics toggle
- **Student Interface**: Persistent left sidebar showing role, team members, current round status, and quick KPI overview
- **Role Switcher**: Dropdown menu in header for accessing different role views

### Dashboard Components
- **KPI Cards**: Compact metric displays (reliability %, cost variance, ESG score) with trend indicators (↑↓) and sparkline visualizations
- **Supplier Cards**: Data-dense cards showing supplier attributes in structured format with scoring badges
- **Round Timeline**: Horizontal stepper showing round progression (Practice → Round 1 → Round 2 → Round 3)
- **Team Activity Feed**: Real-time log of team decisions and actions

### Data Visualization
- **Comparison Tables**: Sortable, filterable tables for supplier evaluation with inline scoring controls
- **Radar Charts**: Multi-axis comparison for supplier KPIs (reliability, cost, ESG, risk)
- **Trend Graphs**: Line charts showing KPI evolution across rounds
- **Scoring Matrix**: Interactive weight sliders for KPI prioritization with live score recalculation

### Forms & Inputs
- **Strategy Configuration**: Tabbed interface for sourcing decisions (local/global, single/multiple, contract terms)
- **Contract Designer**: Multi-step form with duration selectors, volume sliders, and clause toggles
- **ESG Initiative Builder**: Checkbox list with impact previews

### Modals & Overlays
- **Supplier Detail View**: Full-screen modal with comprehensive supplier data, historical performance, and risk assessment
- **Decision Confirmation**: Modal showing impact preview before locking round decisions
- **Tutorial Overlays**: Step-by-step guided tour with spotlight highlighting

### Analytics (Instructor View)
- **Class Overview**: Grid of team cards with live status, current KPIs, and progress indicators
- **Learning Analytics Dashboard**: Multi-panel layout with participation heatmaps, decision trees, and LO achievement meters
- **Individual Reports**: Tabbed interface per student showing role activities, contributions, and competency mapping

---

## Role-Specific Layouts

**Strategic Sourcing Manager**: Dashboard-heavy with strategy overview cards, supplier portfolio visualization, and global/local sourcing toggle panels

**Supplier Evaluation Analyst**: Table-centric with advanced filtering, side-by-side comparison panels, and scoring weight configurators

**Contract & Risk Manager**: Form-focused with contract term builders, risk matrix visualizations, and mitigation strategy checklists

**ESG & Sustainability Officer**: Metric-driven with ESG score breakdowns, sustainability initiative trackers, and impact forecasting charts

---

## Images

**No large hero images** - This is a utility-focused application.

**Icon Usage**: Material Icons for all UI elements (navigation, actions, status indicators, KPI types)
- CDN: Google Material Icons
- Usage: Consistent iconography for supplier types, risk levels, ESG categories, and action buttons

**Data Visualization Graphics**: Use Chart.js or similar library for all graphs and charts (not custom SVG generation)

---

## Responsive Behavior

**Desktop (Primary)**: Multi-column dashboards, side-by-side comparisons, persistent sidebars
**Tablet**: Collapsible sidebar, 2-column grids become single column for complex data
**Mobile**: Full vertical stack, bottom navigation for role switching, simplified metrics views (though lab context assumes desktop)

---

## Critical UI Patterns

- **Persistent Round Indicator**: Always visible current round, time remaining, and lock-in deadline
- **Team Consensus Indicators**: Visual flags showing which team members have completed their role tasks
- **Contextual Help**: Inline tooltips explaining SCOR concepts and KPI calculations
- **Auto-save Indicators**: Subtle confirmation of decision saves with last-saved timestamp
- **Simulation Running State**: Progress indicator during round calculation with estimated completion time

This design framework prioritizes clarity, efficiency, and educational effectiveness over visual flair, ensuring students can focus on strategic decision-making while instructors gain actionable learning analytics.