import {
  type User,
  type InsertUser,
  type Scenario,
  type InsertScenario,
  type Supplier,
  type InsertSupplier,
  type Session,
  type InsertSession,
  type Team,
  type InsertTeam,
  type TeamMember,
  type InsertTeamMember,
  type Decision,
  type InsertDecision,
  type KpiResult,
  type InsertKpiResult,
  type ActivityLog,
  type InsertActivityLog,
  users,
  scenarios,
  suppliers,
  sessions,
  teams,
  teamMembers,
  decisions,
  kpiResults,
  activityLogs,
} from "@shared/schema";
import { db } from "./db";
import { eq, and, or, desc } from "drizzle-orm";

export interface IStorage {
  // Users
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  getAllUsers(): Promise<User[]>;
  getUsersByRole(role: string): Promise<User[]>;
  deleteUser(id: string): Promise<void>;

  // Scenarios
  getScenario(id: string): Promise<Scenario | undefined>;
  getScenarios(): Promise<Scenario[]>;
  getScenariosByInstructor(instructorId: string): Promise<Scenario[]>;
  createScenario(scenario: InsertScenario): Promise<Scenario>;
  updateScenario(id: string, scenario: Partial<InsertScenario>): Promise<Scenario | undefined>;
  deleteScenario(id: string): Promise<void>;

  // Suppliers
  getSupplier(id: string): Promise<Supplier | undefined>;
  getSuppliers(): Promise<Supplier[]>;
  getSuppliersByScenario(scenarioId: string): Promise<Supplier[]>;
  createSupplier(supplier: InsertSupplier): Promise<Supplier>;
  updateSupplier(id: string, supplier: Partial<InsertSupplier>): Promise<Supplier | undefined>;
  deleteSupplier(id: string): Promise<void>;

  // Sessions
  getSession(id: string): Promise<Session | undefined>;
  getSessions(): Promise<Session[]>;
  getSessionsByInstructor(instructorId: string): Promise<Session[]>;
  createSession(session: InsertSession): Promise<Session>;
  updateSession(id: string, session: Partial<InsertSession>): Promise<Session | undefined>;
  deleteSession(id: string): Promise<void>;

  // Teams
  getTeam(id: string): Promise<Team | undefined>;
  getTeams(): Promise<Team[]>;
  getTeamsBySession(sessionId: string): Promise<Team[]>;
  getTeamByMember(userId: string): Promise<Team | undefined>;
  createTeam(team: InsertTeam): Promise<Team>;
  updateTeam(id: string, team: Partial<InsertTeam>): Promise<Team | undefined>;
  deleteTeam(id: string): Promise<void>;

  // Team Members
  getTeamMember(id: string): Promise<TeamMember | undefined>;
  getTeamMembers(teamId: string): Promise<TeamMember[]>;
  getTeamMemberByUser(userId: string): Promise<TeamMember | undefined>;
  createTeamMember(member: InsertTeamMember): Promise<TeamMember>;
  deleteTeamMember(id: string): Promise<void>;

  // Decisions
  getDecision(id: string): Promise<Decision | undefined>;
  getDecisionsByTeam(teamId: string): Promise<Decision[]>;
  getDecisionsByTeamAndRound(teamId: string, roundNumber: number): Promise<Decision[]>;
  createDecision(decision: InsertDecision): Promise<Decision>;
  updateDecision(id: string, decision: Partial<InsertDecision>): Promise<Decision | undefined>;

  // KPI Results
  getKpiResult(id: string): Promise<KpiResult | undefined>;
  getKpiResultsByTeam(teamId: string): Promise<KpiResult[]>;
  createKpiResult(result: InsertKpiResult): Promise<KpiResult>;

  // Activity Logs
  createActivityLog(log: InsertActivityLog): Promise<ActivityLog>;
  getActivityLogsByUser(userId: string): Promise<ActivityLog[]>;
  getActivityLogsByTeam(teamId: string): Promise<ActivityLog[]>;

  // Seeding
  seedTemplateData(): Promise<void>;
}

export class DatabaseStorage implements IStorage {
  // Users
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values(insertUser).returning();
    return user;
  }

  async getAllUsers(): Promise<User[]> {
    return await db.select().from(users);
  }

  async getUsersByRole(role: string): Promise<User[]> {
    return await db.select().from(users).where(eq(users.role, role));
  }

  async deleteUser(id: string): Promise<void> {
    await db.delete(users).where(eq(users.id, id));
  }

  // Scenarios
  async getScenario(id: string): Promise<Scenario | undefined> {
    const [scenario] = await db.select().from(scenarios).where(eq(scenarios.id, id));
    return scenario || undefined;
  }

  async getScenarios(): Promise<Scenario[]> {
    return await db.select().from(scenarios);
  }

  async getScenariosByInstructor(instructorId: string): Promise<Scenario[]> {
    return await db.select().from(scenarios).where(
      or(eq(scenarios.instructorId, instructorId), eq(scenarios.isTemplate, true))
    );
  }

  async createScenario(insertScenario: InsertScenario): Promise<Scenario> {
    const [scenario] = await db.insert(scenarios).values(insertScenario).returning();
    return scenario;
  }

  async updateScenario(id: string, updates: Partial<InsertScenario>): Promise<Scenario | undefined> {
    const [scenario] = await db.update(scenarios).set(updates).where(eq(scenarios.id, id)).returning();
    return scenario || undefined;
  }

  async deleteScenario(id: string): Promise<void> {
    await db.delete(scenarios).where(eq(scenarios.id, id));
  }

  // Suppliers
  async getSupplier(id: string): Promise<Supplier | undefined> {
    const [supplier] = await db.select().from(suppliers).where(eq(suppliers.id, id));
    return supplier || undefined;
  }

  async getSuppliers(): Promise<Supplier[]> {
    return await db.select().from(suppliers);
  }

  async getSuppliersByScenario(scenarioId: string): Promise<Supplier[]> {
    return await db.select().from(suppliers).where(eq(suppliers.scenarioId, scenarioId));
  }

  async createSupplier(insertSupplier: InsertSupplier): Promise<Supplier> {
    const [supplier] = await db.insert(suppliers).values(insertSupplier).returning();
    return supplier;
  }

  async updateSupplier(id: string, updates: Partial<InsertSupplier>): Promise<Supplier | undefined> {
    const [supplier] = await db.update(suppliers).set(updates).where(eq(suppliers.id, id)).returning();
    return supplier || undefined;
  }

  async deleteSupplier(id: string): Promise<void> {
    await db.delete(suppliers).where(eq(suppliers.id, id));
  }

  // Sessions
  async getSession(id: string): Promise<Session | undefined> {
    const [session] = await db.select().from(sessions).where(eq(sessions.id, id));
    return session || undefined;
  }

  async getSessions(): Promise<Session[]> {
    return await db.select().from(sessions);
  }

  async getSessionsByInstructor(instructorId: string): Promise<Session[]> {
    return await db.select().from(sessions).where(eq(sessions.instructorId, instructorId));
  }

  async createSession(insertSession: InsertSession): Promise<Session> {
    const [session] = await db.insert(sessions).values(insertSession).returning();
    return session;
  }

  async updateSession(id: string, updates: Partial<InsertSession>): Promise<Session | undefined> {
    const [session] = await db.update(sessions).set(updates).where(eq(sessions.id, id)).returning();
    return session || undefined;
  }

  async deleteSession(id: string): Promise<void> {
    await db.delete(sessions).where(eq(sessions.id, id));
  }

  // Teams
  async getTeam(id: string): Promise<Team | undefined> {
    const [team] = await db.select().from(teams).where(eq(teams.id, id));
    return team || undefined;
  }

  async getTeams(): Promise<Team[]> {
    return await db.select().from(teams);
  }

  async getTeamsBySession(sessionId: string): Promise<Team[]> {
    return await db.select().from(teams).where(eq(teams.sessionId, sessionId));
  }

  async getTeamByMember(userId: string): Promise<Team | undefined> {
    const member = await this.getTeamMemberByUser(userId);
    if (!member) return undefined;
    return this.getTeam(member.teamId);
  }

  async createTeam(insertTeam: InsertTeam): Promise<Team> {
    const [team] = await db.insert(teams).values(insertTeam).returning();
    return team;
  }

  async updateTeam(id: string, updates: Partial<InsertTeam>): Promise<Team | undefined> {
    const [team] = await db.update(teams).set(updates).where(eq(teams.id, id)).returning();
    return team || undefined;
  }

  async deleteTeam(id: string): Promise<void> {
    await db.delete(teams).where(eq(teams.id, id));
  }

  // Team Members
  async getTeamMember(id: string): Promise<TeamMember | undefined> {
    const [member] = await db.select().from(teamMembers).where(eq(teamMembers.id, id));
    return member || undefined;
  }

  async getTeamMembers(teamId: string): Promise<TeamMember[]> {
    return await db.select().from(teamMembers).where(eq(teamMembers.teamId, teamId));
  }

  async getTeamMemberByUser(userId: string): Promise<TeamMember | undefined> {
    const [member] = await db.select().from(teamMembers).where(eq(teamMembers.userId, userId));
    return member || undefined;
  }

  async createTeamMember(insertMember: InsertTeamMember): Promise<TeamMember> {
    const [member] = await db.insert(teamMembers).values(insertMember).returning();
    return member;
  }

  async deleteTeamMember(id: string): Promise<void> {
    await db.delete(teamMembers).where(eq(teamMembers.id, id));
  }

  // Decisions
  async getDecision(id: string): Promise<Decision | undefined> {
    const [decision] = await db.select().from(decisions).where(eq(decisions.id, id));
    return decision || undefined;
  }

  async getDecisionsByTeam(teamId: string): Promise<Decision[]> {
    return await db.select().from(decisions).where(eq(decisions.teamId, teamId));
  }

  async getDecisionsByTeamAndRound(teamId: string, roundNumber: number): Promise<Decision[]> {
    return await db.select().from(decisions).where(
      and(eq(decisions.teamId, teamId), eq(decisions.roundNumber, roundNumber))
    );
  }

  async createDecision(insertDecision: InsertDecision): Promise<Decision> {
    const [decision] = await db.insert(decisions).values(insertDecision).returning();
    return decision;
  }

  async updateDecision(id: string, updates: Partial<InsertDecision>): Promise<Decision | undefined> {
    const [decision] = await db.update(decisions).set(updates).where(eq(decisions.id, id)).returning();
    return decision || undefined;
  }

  // KPI Results
  async getKpiResult(id: string): Promise<KpiResult | undefined> {
    const [result] = await db.select().from(kpiResults).where(eq(kpiResults.id, id));
    return result || undefined;
  }

  async getKpiResultsByTeam(teamId: string): Promise<KpiResult[]> {
    return await db.select().from(kpiResults)
      .where(eq(kpiResults.teamId, teamId))
      .orderBy(desc(kpiResults.roundNumber));
  }

  async createKpiResult(insertResult: InsertKpiResult): Promise<KpiResult> {
    const [result] = await db.insert(kpiResults).values(insertResult).returning();
    return result;
  }

  // Activity Logs
  async createActivityLog(insertLog: InsertActivityLog): Promise<ActivityLog> {
    const [log] = await db.insert(activityLogs).values(insertLog).returning();
    return log;
  }

  async getActivityLogsByUser(userId: string): Promise<ActivityLog[]> {
    return await db.select().from(activityLogs).where(eq(activityLogs.userId, userId));
  }

  async getActivityLogsByTeam(teamId: string): Promise<ActivityLog[]> {
    return await db.select().from(activityLogs).where(eq(activityLogs.teamId, teamId));
  }

  // Seed template data for scenarios and suppliers
  async seedTemplateData(): Promise<void> {
    // Check if template scenarios already exist
    const existingScenarios = await db.select().from(scenarios).where(eq(scenarios.isTemplate, true));
    if (existingScenarios.length > 0) {
      return; // Already seeded
    }

    // Create Electronics Scenario
    const [electronicsScenario] = await db.insert(scenarios).values({
      name: "Global Electronics Sourcing",
      description: "Source electronic components from global suppliers with varying reliability, cost, and ESG profiles.",
      instructorId: "template",
      productCategory: "electronics",
      demandPattern: "fluctuating",
      targetReliability: 90,
      targetMaxCost: 150000,
      targetMinEsg: 70,
      isTemplate: true,
    }).returning();

    // Create FMCG Scenario
    const [fmcgScenario] = await db.insert(scenarios).values({
      name: "Sustainable FMCG Sourcing",
      description: "Balance cost efficiency with sustainability in fast-moving consumer goods supply chain.",
      instructorId: "template",
      productCategory: "fmcg",
      demandPattern: "stable",
      targetReliability: 95,
      targetMaxCost: 80000,
      targetMinEsg: 80,
      isTemplate: true,
    }).returning();

    // Seed Electronics Suppliers
    await db.insert(suppliers).values([
      {
        scenarioId: electronicsScenario.id,
        name: "TechParts Asia",
        country: "China",
        isLocal: false,
        unitPrice: 45,
        volumeDiscount: 8,
        leadTime: 21,
        leadTimeVariability: 0.15,
        onTimeDeliveryRate: 0.88,
        defectRate: 0.02,
        esgEnvironmental: 55,
        esgSocial: 60,
        esgGovernance: 65,
        riskLevel: "medium",
        capacity: 50000,
      },
      {
        scenarioId: electronicsScenario.id,
        name: "EuroComponents GmbH",
        country: "Germany",
        isLocal: false,
        unitPrice: 72,
        volumeDiscount: 5,
        leadTime: 14,
        leadTimeVariability: 0.08,
        onTimeDeliveryRate: 0.96,
        defectRate: 0.005,
        esgEnvironmental: 88,
        esgSocial: 90,
        esgGovernance: 92,
        riskLevel: "low",
        capacity: 25000,
      },
      {
        scenarioId: electronicsScenario.id,
        name: "LocalTech Solutions",
        country: "Indonesia",
        isLocal: true,
        unitPrice: 55,
        volumeDiscount: 6,
        leadTime: 7,
        leadTimeVariability: 0.1,
        onTimeDeliveryRate: 0.92,
        defectRate: 0.015,
        esgEnvironmental: 70,
        esgSocial: 75,
        esgGovernance: 72,
        riskLevel: "low",
        capacity: 30000,
      },
      {
        scenarioId: electronicsScenario.id,
        name: "QuickChip Taiwan",
        country: "Taiwan",
        isLocal: false,
        unitPrice: 48,
        volumeDiscount: 10,
        leadTime: 18,
        leadTimeVariability: 0.12,
        onTimeDeliveryRate: 0.91,
        defectRate: 0.018,
        esgEnvironmental: 62,
        esgSocial: 70,
        esgGovernance: 75,
        riskLevel: "medium",
        capacity: 40000,
      },
      {
        scenarioId: electronicsScenario.id,
        name: "BudgetParts India",
        country: "India",
        isLocal: false,
        unitPrice: 35,
        volumeDiscount: 12,
        leadTime: 28,
        leadTimeVariability: 0.25,
        onTimeDeliveryRate: 0.78,
        defectRate: 0.04,
        esgEnvironmental: 45,
        esgSocial: 50,
        esgGovernance: 55,
        riskLevel: "high",
        capacity: 80000,
      },
    ]);

    // Seed FMCG Suppliers
    await db.insert(suppliers).values([
      {
        scenarioId: fmcgScenario.id,
        name: "GreenPack Solutions",
        country: "Indonesia",
        isLocal: true,
        unitPrice: 12,
        volumeDiscount: 15,
        leadTime: 5,
        leadTimeVariability: 0.05,
        onTimeDeliveryRate: 0.97,
        defectRate: 0.008,
        esgEnvironmental: 92,
        esgSocial: 88,
        esgGovernance: 85,
        riskLevel: "low",
        capacity: 100000,
      },
      {
        scenarioId: fmcgScenario.id,
        name: "FastPack Thailand",
        country: "Thailand",
        isLocal: false,
        unitPrice: 9,
        volumeDiscount: 8,
        leadTime: 10,
        leadTimeVariability: 0.08,
        onTimeDeliveryRate: 0.93,
        defectRate: 0.012,
        esgEnvironmental: 75,
        esgSocial: 72,
        esgGovernance: 78,
        riskLevel: "low",
        capacity: 150000,
      },
      {
        scenarioId: fmcgScenario.id,
        name: "CheapPack Vietnam",
        country: "Vietnam",
        isLocal: false,
        unitPrice: 6,
        volumeDiscount: 5,
        leadTime: 14,
        leadTimeVariability: 0.18,
        onTimeDeliveryRate: 0.82,
        defectRate: 0.025,
        esgEnvironmental: 52,
        esgSocial: 55,
        esgGovernance: 58,
        riskLevel: "high",
        capacity: 200000,
      },
      {
        scenarioId: fmcgScenario.id,
        name: "EcoPack Australia",
        country: "Australia",
        isLocal: false,
        unitPrice: 18,
        volumeDiscount: 3,
        leadTime: 8,
        leadTimeVariability: 0.06,
        onTimeDeliveryRate: 0.98,
        defectRate: 0.003,
        esgEnvironmental: 95,
        esgSocial: 92,
        esgGovernance: 94,
        riskLevel: "low",
        capacity: 40000,
      },
    ]);
  }
}

export const storage = new DatabaseStorage();
