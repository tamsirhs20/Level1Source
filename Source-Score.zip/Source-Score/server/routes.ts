import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertUserSchema, insertScenarioSchema, insertSessionSchema, insertTeamSchema, insertTeamMemberSchema, insertDecisionSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  // Authentication Routes
  app.post("/api/auth/register", async (req, res) => {
    try {
      const data = insertUserSchema.parse(req.body);
      const existing = await storage.getUserByUsername(data.username);
      if (existing) {
        return res.status(400).json({ error: "Username already exists" });
      }
      const user = await storage.createUser(data);
      res.json({ user: { ...user, password: undefined } });
    } catch (error) {
      res.status(400).json({ error: "Invalid data" });
    }
  });

  app.post("/api/auth/login", async (req, res) => {
    try {
      const { username, password } = req.body;
      const user = await storage.getUserByUsername(username);
      if (!user || user.password !== password) {
        return res.status(401).json({ error: "Invalid credentials" });
      }
      res.json({ user: { ...user, password: undefined } });
    } catch (error) {
      res.status(400).json({ error: "Invalid data" });
    }
  });

  // Supplier Routes
  app.get("/api/suppliers", async (req, res) => {
    const suppliers = await storage.getSuppliers();
    res.json(suppliers);
  });

  app.get("/api/suppliers/:id", async (req, res) => {
    const supplier = await storage.getSupplier(req.params.id);
    if (!supplier) {
      return res.status(404).json({ error: "Supplier not found" });
    }
    res.json(supplier);
  });

  // Scenario Routes
  app.get("/api/scenarios", async (req, res) => {
    const scenarios = await storage.getScenarios();
    res.json(scenarios);
  });

  app.post("/api/scenarios", async (req, res) => {
    try {
      const data = insertScenarioSchema.parse(req.body);
      const scenario = await storage.createScenario(data);
      res.json(scenario);
    } catch (error) {
      res.status(400).json({ error: "Invalid data" });
    }
  });

  app.patch("/api/scenarios/:id", async (req, res) => {
    const scenario = await storage.updateScenario(req.params.id, req.body);
    if (!scenario) {
      return res.status(404).json({ error: "Scenario not found" });
    }
    res.json(scenario);
  });

  app.delete("/api/scenarios/:id", async (req, res) => {
    await storage.deleteScenario(req.params.id);
    res.json({ success: true });
  });

  // Session Routes
  app.get("/api/sessions", async (req, res) => {
    const sessions = await storage.getSessions();
    res.json(sessions);
  });

  app.post("/api/sessions", async (req, res) => {
    try {
      const data = insertSessionSchema.parse(req.body);
      const session = await storage.createSession(data);
      res.json(session);
    } catch (error) {
      res.status(400).json({ error: "Invalid data" });
    }
  });

  app.patch("/api/sessions/:id", async (req, res) => {
    const session = await storage.updateSession(req.params.id, req.body);
    if (!session) {
      return res.status(404).json({ error: "Session not found" });
    }
    res.json(session);
  });

  app.post("/api/sessions/:id/advance", async (req, res) => {
    const session = await storage.getSession(req.params.id);
    if (!session) {
      return res.status(404).json({ error: "Session not found" });
    }
    const updated = await storage.updateSession(req.params.id, {
      currentRound: (session.currentRound || 0) + 1,
    });
    res.json(updated);
  });

  app.delete("/api/sessions/:id", async (req, res) => {
    await storage.deleteSession(req.params.id);
    res.json({ success: true });
  });

  // Team Routes
  app.get("/api/teams", async (req, res) => {
    const teams = await storage.getTeams();
    const teamsWithMembers = await Promise.all(
      teams.map(async (team) => {
        const members = await storage.getTeamMembers(team.id);
        const membersWithUsers = await Promise.all(
          members.map(async (member) => {
            const user = await storage.getUser(member.userId);
            return { ...member, user: user ? { ...user, password: undefined } : null };
          })
        );
        const session = await storage.getSession(team.sessionId);
        return { ...team, members: membersWithUsers.filter((m) => m.user), session };
      })
    );
    res.json(teamsWithMembers);
  });

  app.post("/api/teams", async (req, res) => {
    try {
      const data = insertTeamSchema.parse(req.body);
      const team = await storage.createTeam(data);
      res.json(team);
    } catch (error) {
      res.status(400).json({ error: "Invalid data" });
    }
  });

  app.patch("/api/teams/:id", async (req, res) => {
    const team = await storage.updateTeam(req.params.id, req.body);
    if (!team) {
      return res.status(404).json({ error: "Team not found" });
    }
    res.json(team);
  });

  app.delete("/api/teams/:id", async (req, res) => {
    await storage.deleteTeam(req.params.id);
    res.json({ success: true });
  });

  // Team Member Routes
  app.post("/api/team-members", async (req, res) => {
    try {
      const data = insertTeamMemberSchema.parse(req.body);
      const member = await storage.createTeamMember(data);
      res.json(member);
    } catch (error) {
      res.status(400).json({ error: "Invalid data" });
    }
  });

  app.delete("/api/team-members/:id", async (req, res) => {
    await storage.deleteTeamMember(req.params.id);
    res.json({ success: true });
  });

  // Decision Routes
  app.post("/api/decisions", async (req, res) => {
    try {
      const data = insertDecisionSchema.parse(req.body);
      const decision = await storage.createDecision(data);
      res.json(decision);
    } catch (error) {
      res.status(400).json({ error: "Invalid data" });
    }
  });

  app.post("/api/decisions/lock", async (req, res) => {
    try {
      const { decisions, teamId, roundNumber } = req.body;
      // Save all decisions and calculate KPIs
      for (const dec of decisions) {
        await storage.createDecision({
          teamId,
          roundNumber,
          supplierId: dec.supplierId,
          volumeAllocation: dec.allocation,
          contractDuration: dec.contractDuration,
          contractType: dec.contractType,
          isLocked: true,
        });
      }

      // Calculate and save KPI results
      let reliabilityScore = 0;
      let totalCost = 0;
      let esgScore = 0;
      let riskIndex = 0;

      for (const dec of decisions) {
        const supplier = await storage.getSupplier(dec.supplierId);
        if (supplier) {
          const weight = dec.allocation / 100;
          reliabilityScore += supplier.onTimeDeliveryRate * 100 * weight;
          totalCost += supplier.unitPrice * 1000 * weight;
          esgScore += ((supplier.esgEnvironmental + supplier.esgSocial + supplier.esgGovernance) / 3) * weight;
          riskIndex += (supplier.riskLevel === "low" ? 1 : supplier.riskLevel === "medium" ? 2 : 3) * weight;
        }
      }

      await storage.createKpiResult({
        teamId,
        roundNumber,
        reliabilityScore,
        totalCost,
        esgScore,
        riskIndex,
        agilityScore: 75,
        onTimeDelivery: reliabilityScore,
        qualityScore: 90,
      });

      // Advance team to next round
      const team = await storage.getTeam(teamId);
      if (team) {
        await storage.updateTeam(teamId, { currentRound: (team.currentRound || 0) + 1 });
      }

      res.json({ success: true });
    } catch (error) {
      res.status(400).json({ error: "Failed to lock decisions" });
    }
  });

  // Instructor Routes
  app.get("/api/instructor/scenarios", async (req, res) => {
    const scenarios = await storage.getScenarios();
    res.json(scenarios);
  });

  app.get("/api/instructor/sessions", async (req, res) => {
    const sessions = await storage.getSessions();
    res.json(sessions);
  });

  app.get("/api/instructor/teams", async (req, res) => {
    const teams = await storage.getTeams();
    const teamsWithMembers = await Promise.all(
      teams.map(async (team) => {
        const members = await storage.getTeamMembers(team.id);
        const membersWithUsers = await Promise.all(
          members.map(async (member) => {
            const user = await storage.getUser(member.userId);
            return { ...member, user: user ? { ...user, password: undefined } : null };
          })
        );
        const session = await storage.getSession(team.sessionId);
        return { ...team, members: membersWithUsers.filter((m) => m.user), session };
      })
    );
    res.json(teamsWithMembers);
  });

  app.get("/api/instructor/students", async (req, res) => {
    const students = await storage.getUsersByRole("student");
    res.json(students.map((s) => ({ ...s, password: undefined })));
  });

  app.get("/api/instructor/kpi-results", async (req, res) => {
    const teams = await storage.getTeams();
    const allResults: any[] = [];
    for (const team of teams) {
      const results = await storage.getKpiResultsByTeam(team.id);
      allResults.push(...results);
    }
    res.json(allResults);
  });

  // Student Routes
  app.get("/api/student/my-team", async (req, res) => {
    // For demo, just return first team or null
    const teams = await storage.getTeams();
    if (teams.length > 0) {
      res.json(teams[0]);
    } else {
      res.json(null);
    }
  });

  app.get("/api/student/my-team-details", async (req, res) => {
    const teams = await storage.getTeams();
    if (teams.length === 0) {
      return res.json(null);
    }
    const team = teams[0];
    const members = await storage.getTeamMembers(team.id);
    const membersWithUsers = await Promise.all(
      members.map(async (member) => {
        const user = await storage.getUser(member.userId);
        return { ...member, user: user ? { ...user, password: undefined } : null };
      })
    );
    res.json({ ...team, members: membersWithUsers.filter((m) => m.user) });
  });

  app.get("/api/student/active-session", async (req, res) => {
    const sessions = await storage.getSessions();
    const active = sessions.find((s) => s.isActive);
    res.json(active || null);
  });

  app.get("/api/student/latest-kpi", async (req, res) => {
    const teams = await storage.getTeams();
    if (teams.length === 0) {
      return res.json(null);
    }
    const results = await storage.getKpiResultsByTeam(teams[0].id);
    res.json(results[0] || null);
  });

  app.get("/api/student/kpi-history", async (req, res) => {
    const teams = await storage.getTeams();
    if (teams.length === 0) {
      return res.json([]);
    }
    const results = await storage.getKpiResultsByTeam(teams[0].id);
    res.json(results);
  });

  // Admin Routes
  app.get("/api/admin/users", async (req, res) => {
    const users = await storage.getAllUsers();
    res.json(users.map((u) => ({ ...u, password: undefined })));
  });

  app.delete("/api/admin/users/:id", async (req, res) => {
    await storage.deleteUser(req.params.id);
    res.json({ success: true });
  });

  return httpServer;
}
